<?php
require_once __DIR__ . '/backend/lib/auth_guard.php';
om_require_login();

require_once __DIR__ . '/backend/config/database.php';

$lang = $_SESSION['lang'] ?? 'bg';
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'] ?? 'User';
$user_email = $_SESSION['email'] ?? '';

// Get profile data
$profile = null;
try {
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT * FROM user_profiles WHERE user_id = ?");
    $stmt->execute(array($user_id));
    $profile = $stmt->fetch();
} catch (Exception $e) {
    error_log("Profile fetch error: " . $e->getMessage());
}

$t = array(
  'bg' => array(
    'title' => 'Моят профил',
    'subtitle' => 'Преглед на лични данни',
    'personal_info' => 'Лична информация',
    'name' => 'Име',
    'email' => 'Email',
    'driver_section' => 'Шофьорски данни',
    'driver_license' => 'Номер на шофьорска книжка',
    'driver_license_ph' => 'напр. 123456789',
    'car_section' => 'Автомобилни данни',
    'car_registration' => 'Номер на автомобил',
    'car_registration_ph' => 'напр. СА 1234 ВВ',
    'car_make_model' => 'Марка и модел',
    'car_make_model_ph' => 'напр. Mercedes Sprinter',
    'documents_section' => 'Документи и застраховки',
    'civil_insurance' => 'Гражданска застраховка',
    'civil_insurance_expiry' => 'Изтича на',
    'vignette' => 'Винетка',
    'vignette_expiry' => 'Изтича на',
    'vehicle_inspection' => 'Технически преглед',
    'vehicle_inspection_expiry' => 'Изтича на',
    'btn_edit' => 'Редактирай данни',
    'btn_save' => 'Запази промените',
    'btn_cancel' => 'Отказ',
    'btn_back' => 'Назад към Dashboard',
    'no_data' => 'Няма въведени данни',
    'edit_profile' => 'Редакция на профил',
    'success' => 'Профилът е обновен успешно!',
    'error' => 'Грешка при запазване на профила.',
  ),
  'en' => array(
    'title' => 'My Profile',
    'subtitle' => 'View personal data',
    'personal_info' => 'Personal Information',
    'name' => 'Name',
    'email' => 'Email',
    'driver_section' => 'Driver Information',
    'driver_license' => 'Driver License Number',
    'driver_license_ph' => 'e.g. 123456789',
    'car_section' => 'Vehicle Information',
    'car_registration' => 'Vehicle Registration',
    'car_registration_ph' => 'e.g. CA 1234 BB',
    'car_make_model' => 'Make and Model',
    'car_make_model_ph' => 'e.g. Mercedes Sprinter',
    'documents_section' => 'Documents and Insurance',
    'civil_insurance' => 'Civil Insurance',
    'civil_insurance_expiry' => 'Expires on',
    'vignette' => 'Vignette',
    'vignette_expiry' => 'Expires on',
    'vehicle_inspection' => 'Vehicle Inspection',
    'vehicle_inspection_expiry' => 'Expires on',
    'btn_edit' => 'Edit Data',
    'btn_save' => 'Save Changes',
    'btn_cancel' => 'Cancel',
    'btn_back' => 'Back to Dashboard',
    'no_data' => 'No data entered',
    'edit_profile' => 'Edit Profile',
    'success' => 'Profile updated successfully!',
    'error' => 'Error saving profile.',
  ),
  'ru' => array(
    'title' => 'Мой профиль',
    'subtitle' => 'Просмотр личных данных',
    'personal_info' => 'Личная информация',
    'name' => 'Имя',
    'email' => 'Email',
    'driver_section' => 'Водительские данные',
    'driver_license' => 'Номер водительских прав',
    'driver_license_ph' => 'напр. 123456789',
    'car_section' => 'Данные автомобиля',
    'car_registration' => 'Регистрационный номер',
    'car_registration_ph' => 'напр. CA 1234 BB',
    'car_make_model' => 'Марка и модель',
    'car_make_model_ph' => 'напр. Mercedes Sprinter',
    'documents_section' => 'Документы и страховка',
    'civil_insurance' => 'Гражданская страховка',
    'civil_insurance_expiry' => 'Истекает',
    'vignette' => 'Виньетка',
    'vignette_expiry' => 'Истекает',
    'vehicle_inspection' => 'Техосмотр',
    'vehicle_inspection_expiry' => 'Истекает',
    'btn_edit' => 'Редактировать',
    'btn_save' => 'Сохранить',
    'btn_cancel' => 'Отмена',
    'btn_back' => 'Назад к панели',
    'no_data' => 'Данные не введены',
    'edit_profile' => 'Редактирование профиля',
    'success' => 'Профиль обновлен успешно!',
    'error' => 'Ошибка сохранения профиля.',
  ),
);

$tr = $t[$lang];
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tr['title']; ?> - Office Manager</title>
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{background:#1a1a1a;color:#e5e5e5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;min-height:100vh;padding:20px 20px 100px}
        .container{max-width:900px;margin:0 auto}
        .header{text-align:center;margin-bottom:48px;padding-top:60px}
        .logo{width:64px;height:64px;background:linear-gradient(135deg,#D4AF37,#C5A028);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:28px;font-weight:bold;color:#1a1a1a;box-shadow:0 0 0 3px rgba(212,175,55,.3);margin-bottom:24px}
        h1{font-size:32px;font-weight:300;margin-bottom:12px}
        .subtitle{color:#999;font-size:16px}
        .card{background:#2a2a2a;border:1px solid #3a3a3a;border-radius:12px;padding:32px;margin-bottom:24px}
        .section-title{font-size:18px;font-weight:600;color:#D4AF37;margin-bottom:24px;padding-bottom:12px;border-bottom:1px solid #3a3a3a}
        .data-table{width:100%}
        .data-row{display:flex;padding:12px 0;border-bottom:1px solid #3a3a3a}
        .data-row:last-child{border-bottom:none}
        .data-label{flex:0 0 200px;font-weight:600;color:#999;font-size:14px}
        .data-value{flex:1;color:#e5e5e5;font-size:14px}
        .no-data{color:#666;font-style:italic}
        .actions{display:flex;gap:16px;justify-content:center;margin-top:32px}
        .btn{padding:14px 32px;border-radius:8px;font-size:16px;font-weight:600;cursor:pointer;transition:.2s;border:none;text-decoration:none;display:inline-block}
        .btn-primary{background:linear-gradient(135deg,#D4AF37,#C5A028);color:#1a1a1a}
        .btn-primary:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(212,175,55,.3)}
        .btn-secondary{background:#2a2a2a;border:1px solid #3a3a3a;color:#e5e5e5}
        .btn-secondary:hover{border-color:#D4AF37}
        .alert{padding:16px;border-radius:8px;margin-bottom:24px;font-size:14px}
        .alert-success{background:rgba(34,197,94,.1);border:1px solid #22c55e;color:#22c55e}
        .alert-error{background:rgba(248,113,113,.1);border:1px solid #f87171;color:#f87171}
        
        /* Modal/Popup */
        .modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.8);z-index:1000;align-items:center;justify-content:center}
        .modal.active{display:flex}
        .modal-content{background:#2a2a2a;border:1px solid #3a3a3a;border-radius:12px;padding:32px;max-width:600px;width:90%;max-height:90vh;overflow-y:auto}
        .modal-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid #3a3a3a}
        .modal-title{font-size:24px;font-weight:600;color:#D4AF37}
        .modal-close{background:none;border:none;color:#999;font-size:28px;cursor:pointer;padding:0;width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:4px;transition:.2s}
        .modal-close:hover{background:#3a3a3a;color:#e5e5e5}
        .form-group{margin-bottom:20px}
        .form-label{display:block;margin-bottom:8px;font-size:14px;font-weight:600;color:#e5e5e5}
        .input{width:100%;background:#1a1a1a;border:1px solid #3a3a3a;padding:12px 16px;color:#e5e5e5;border-radius:8px;font-size:15px;font-family:inherit}
        .input:focus{outline:0;border-color:#D4AF37;box-shadow:0 0 0 3px rgba(212,175,55,.1)}
        .input::placeholder{color:#666}
        .form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
        
        @media (max-width:768px){
            .header{padding-top:80px}
            .data-row{flex-direction:column;gap:4px}
            .data-label{flex:none}
            .form-row{grid-template-columns:1fr}
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="logo">OM</div>
        <h1><?php echo $tr['title']; ?></h1>
        <p class="subtitle"><?php echo $tr['subtitle']; ?></p>
    </div>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success"><?php echo $tr['success']; ?></div>
    <?php endif; ?>

    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-error"><?php echo $tr['error']; ?></div>
    <?php endif; ?>

    <!-- Personal Info -->
    <div class="card">
        <h3 class="section-title"><?php echo $tr['personal_info']; ?></h3>
        <div class="data-table">
            <div class="data-row">
                <div class="data-label"><?php echo $tr['name']; ?></div>
                <div class="data-value"><?php echo htmlspecialchars($user_name); ?></div>
            </div>
            <div class="data-row">
                <div class="data-label"><?php echo $tr['email']; ?></div>
                <div class="data-value"><?php echo htmlspecialchars($user_email); ?></div>
            </div>
        </div>
    </div>

    <!-- Driver Info -->
    <div class="card">
        <h3 class="section-title"><?php echo $tr['driver_section']; ?></h3>
        <div class="data-table">
            <div class="data-row">
                <div class="data-label"><?php echo $tr['driver_license']; ?></div>
                <div class="data-value">
                    <?php echo $profile && $profile['driver_license_number'] ? htmlspecialchars($profile['driver_license_number']) : '<span class="no-data">' . $tr['no_data'] . '</span>'; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Car Info -->
    <div class="card">
        <h3 class="section-title"><?php echo $tr['car_section']; ?></h3>
        <div class="data-table">
            <div class="data-row">
                <div class="data-label"><?php echo $tr['car_registration']; ?></div>
                <div class="data-value">
                    <?php echo $profile && $profile['car_registration'] ? htmlspecialchars($profile['car_registration']) : '<span class="no-data">' . $tr['no_data'] . '</span>'; ?>
                </div>
            </div>
            <div class="data-row">
                <div class="data-label"><?php echo $tr['car_make_model']; ?></div>
                <div class="data-value">
                    <?php echo $profile && $profile['car_make_model'] ? htmlspecialchars($profile['car_make_model']) : '<span class="no-data">' . $tr['no_data'] . '</span>'; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Documents -->
    <div class="card">
        <h3 class="section-title"><?php echo $tr['documents_section']; ?></h3>
        <div class="data-table">
            <div class="data-row">
                <div class="data-label"><?php echo $tr['civil_insurance']; ?></div>
                <div class="data-value">
                    <?php echo $profile && $profile['civil_insurance_expiry'] ? date('d.m.Y', strtotime($profile['civil_insurance_expiry'])) : '<span class="no-data">' . $tr['no_data'] . '</span>'; ?>
                </div>
            </div>
            <div class="data-row">
                <div class="data-label"><?php echo $tr['vignette']; ?></div>
                <div class="data-value">
                    <?php echo $profile && $profile['vignette_expiry'] ? date('d.m.Y', strtotime($profile['vignette_expiry'])) : '<span class="no-data">' . $tr['no_data'] . '</span>'; ?>
                </div>
            </div>
            <div class="data-row">
                <div class="data-label"><?php echo $tr['vehicle_inspection']; ?></div>
                <div class="data-value">
                    <?php echo $profile && $profile['vehicle_inspection_expiry'] ? date('d.m.Y', strtotime($profile['vehicle_inspection_expiry'])) : '<span class="no-data">' . $tr['no_data'] . '</span>'; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="actions">
        <a href="dashboard.php?lang=<?php echo $lang; ?>" class="btn btn-secondary"><?php echo $tr['btn_back']; ?></a>
        <button onclick="openEditModal()" class="btn btn-primary"><?php echo $tr['btn_edit']; ?></button>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal" id="editModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title"><?php echo $tr['edit_profile']; ?></h3>
            <button class="modal-close" onclick="closeEditModal()">&times;</button>
        </div>
        
        <form method="POST" action="backend/api/profile/update-profile.php">
            <input type="hidden" name="lang" value="<?php echo $lang; ?>">
            
            <div class="form-group">
                <label class="form-label"><?php echo $tr['driver_license']; ?></label>
                <input type="text" name="driver_license_number" class="input" 
                       value="<?php echo $profile ? htmlspecialchars($profile['driver_license_number']) : ''; ?>"
                       placeholder="<?php echo $tr['driver_license_ph']; ?>">
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label"><?php echo $tr['car_registration']; ?></label>
                    <input type="text" name="car_registration" class="input"
                           value="<?php echo $profile ? htmlspecialchars($profile['car_registration']) : ''; ?>"
                           placeholder="<?php echo $tr['car_registration_ph']; ?>">
                </div>
                <div class="form-group">
                    <label class="form-label"><?php echo $tr['car_make_model']; ?></label>
                    <input type="text" name="car_make_model" class="input"
                           value="<?php echo $profile ? htmlspecialchars($profile['car_make_model']) : ''; ?>"
                           placeholder="<?php echo $tr['car_make_model_ph']; ?>">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label"><?php echo $tr['civil_insurance_expiry']; ?></label>
                    <input type="date" name="civil_insurance_expiry" class="input"
                           value="<?php echo $profile && $profile['civil_insurance_expiry'] ? $profile['civil_insurance_expiry'] : ''; ?>">
                </div>
                <div class="form-group">
                    <label class="form-label"><?php echo $tr['vignette_expiry']; ?></label>
                    <input type="date" name="vignette_expiry" class="input"
                           value="<?php echo $profile && $profile['vignette_expiry'] ? $profile['vignette_expiry'] : ''; ?>">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label"><?php echo $tr['vehicle_inspection_expiry']; ?></label>
                <input type="date" name="vehicle_inspection_expiry" class="input"
                       value="<?php echo $profile && $profile['vehicle_inspection_expiry'] ? $profile['vehicle_inspection_expiry'] : ''; ?>">
            </div>

            <div style="display:flex;gap:12px;justify-content:flex-end;margin-top:24px">
                <button type="button" onclick="closeEditModal()" class="btn btn-secondary"><?php echo $tr['btn_cancel']; ?></button>
                <button type="submit" class="btn btn-primary"><?php echo $tr['btn_save']; ?></button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditModal() {
    document.getElementById('editModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeEditModal() {
    document.getElementById('editModal').classList.remove('active');
    document.body.style.overflow = 'auto';
}

// Close on outside click
document.getElementById('editModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeEditModal();
    }
});

// Close on ESC key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeEditModal();
    }
});
</script>

<?php include __DIR__ . '/components/user-menu.php'; ?>
</body>
</html>
