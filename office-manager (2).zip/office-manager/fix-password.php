<?php
// Script to generate password hash and update user

require_once __DIR__ . '/backend/lib/db.php';

$email = 'test@test.com';
$password = 'test123';

// Generate proper hash
$hash = password_hash($password, PASSWORD_DEFAULT);

echo "<h2>Password Hash Generator</h2>";
echo "<p>Email: <strong>$email</strong></p>";
echo "<p>Password: <strong>$password</strong></p>";
echo "<p>Hash: <code>$hash</code></p>";

// Update database
$pdo = om_pdo();
$stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE email = ?");
$stmt->execute([$hash, $email]);

echo "<hr>";
echo "<p style='color: green;'><strong>✅ Password updated successfully!</strong></p>";
echo "<p>Now try to login with:</p>";
echo "<ul>";
echo "<li>Email: <strong>$email</strong></li>";
echo "<li>Password: <strong>$password</strong></li>";
echo "</ul>";
echo "<p><a href='/office-manager/login.php'>Go to Login Page</a></p>";
