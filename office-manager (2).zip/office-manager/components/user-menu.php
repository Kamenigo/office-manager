<?php
// User menu component - include this in every page after login
// Usage: include __DIR__ . '/components/user-menu.php';

$userName = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : 'User';
$userEmail = isset($_SESSION['email']) ? $_SESSION['email'] : '';

// Get initials
$userInitials = '';
if ($userName) {
  $nameParts = explode(' ', $userName);
  $userInitials = strtoupper(substr($nameParts[0], 0, 1));
  if (isset($nameParts[1])) {
    $userInitials .= strtoupper(substr($nameParts[1], 0, 1));
  }
}

$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'bg';

$menu_t = array(
  'bg' => array(
    'dashboard' => 'Табло',
    'tasks' => 'Задачи',
    'orders' => 'Поръчки',
    'purchases' => 'Покупки',
    'clients' => 'Клиенти',
    'invoices' => 'Фактури',
    'reports' => 'Отчети',
    'users' => 'Потребители',
    'settings' => 'Настройки',
    'profile' => 'Профил',
    'logout' => 'Изход'
  ),
  'en' => array(
    'dashboard' => 'Dashboard',
    'tasks' => 'Tasks',
    'orders' => 'Orders',
    'purchases' => 'Purchases',
    'clients' => 'Clients',
    'invoices' => 'Invoices',
    'reports' => 'Reports',
    'users' => 'Users',
    'settings' => 'Settings',
    'profile' => 'Profile',
    'logout' => 'Logout'
  ),
  'ru' => array(
    'dashboard' => 'Панель',
    'tasks' => 'Задачи',
    'orders' => 'Заказы',
    'purchases' => 'Покупки',
    'clients' => 'Клиенты',
    'invoices' => 'Счета',
    'reports' => 'Отчеты',
    'users' => 'Пользователи',
    'settings' => 'Настройки',
    'profile' => 'Профиль',
    'logout' => 'Выход'
  ),
);
$menu_tr = $menu_t[$lang];
?>

<style>
.user-menu-container{position:fixed;top:16px;right:16px;z-index:1000}
.user-trigger{display:flex;align-items:center;gap:8px;background:#2a2a2a;border:1px solid #3a3a3a;padding:6px 12px 6px 6px;border-radius:20px;cursor:pointer;transition:.2s}
.user-trigger:hover{border-color:#D4AF37;background:#2d2a23}
.user-avatar{width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#D4AF37,#C5A028);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;color:#1a1a1a}
.user-name{font-size:14px;color:#e5e5e5;font-weight:500;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.user-dropdown{position:absolute;top:calc(100% + 8px);right:0;min-width:180px;background:#2a2a2a;border:1px solid #3a3a3a;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,.3);opacity:0;visibility:hidden;transform:translateY(-10px);transition:.2s}
.user-dropdown.active{opacity:1;visibility:visible;transform:translateY(0)}
.dropdown-item{display:flex;align-items:center;gap:10px;padding:10px 16px;color:#e5e5e5;text-decoration:none;font-size:14px;transition:.2s;border-bottom:1px solid #3a3a3a}
.dropdown-item:last-child{border-bottom:none}
.dropdown-item:hover{background:#333}
.dropdown-item.logout{color:#f87171}
.dropdown-item.logout:hover{background:rgba(248,113,113,.1)}
@media (max-width:768px){
  .user-menu-container{top:12px;right:12px}
  .user-name{max-width:100px}
}
</style>

<div class="user-menu-container">
  <div class="user-trigger" id="userMenuTrigger">
    <div class="user-avatar"><?php echo $userInitials; ?></div>
    <span class="user-name"><?php echo htmlspecialchars($userName); ?></span>
  </div>
  
  <div class="user-dropdown" id="userDropdown">
    <a href="/office-manager/dashboard.php?lang=<?php echo $lang; ?>" class="dropdown-item">
      📊 <?php echo $menu_tr['dashboard']; ?>
    </a>
    <a href="#" class="dropdown-item">
      📋 <?php echo $menu_tr['tasks']; ?>
    </a>
    <a href="#" class="dropdown-item">
      📦 <?php echo $menu_tr['orders']; ?>
    </a>
    <a href="#" class="dropdown-item">
      🛒 <?php echo $menu_tr['purchases']; ?>
    </a>
    <a href="#" class="dropdown-item">
      👥 <?php echo $menu_tr['clients']; ?>
    </a>
    <a href="#" class="dropdown-item">
      📄 <?php echo $menu_tr['invoices']; ?>
    </a>
    <a href="#" class="dropdown-item">
      📈 <?php echo $menu_tr['reports']; ?>
    </a>
    <?php if (isset($_SESSION['role']) && in_array($_SESSION['role'], array('admin', 'pm'))): ?>
    <a href="/office-manager/manage-users.php?lang=<?php echo $lang; ?>" class="dropdown-item">
      👤 <?php echo $menu_tr['users']; ?>
    </a>
    <?php endif; ?>
    <a href="#" class="dropdown-item">
      ⚙️ <?php echo $menu_tr['settings']; ?>
    </a>
    <a href="/office-manager/profile.php?lang=<?php echo $lang; ?>" class="dropdown-item">
      🧑 <?php echo $menu_tr['profile']; ?>
    </a>
    <a href="/office-manager/backend/api/auth/logout.php" class="dropdown-item logout">
      🚪 <?php echo $menu_tr['logout']; ?>
    </a>
  </div>
</div>

<script>
(function() {
  const trigger = document.getElementById('userMenuTrigger');
  const dropdown = document.getElementById('userDropdown');
  
  if (trigger && dropdown) {
    trigger.addEventListener('click', function(e) {
      e.stopPropagation();
      dropdown.classList.toggle('active');
    });
    
    document.addEventListener('click', function(e) {
      if (!trigger.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.remove('active');
      }
    });
  }
})();
</script>
