<?php
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Language
$lang = isset($_GET['lang']) ? $_GET['lang'] : (isset($_SESSION['lang']) ? $_SESSION['lang'] : 'bg');
if (in_array($lang, array('bg', 'en', 'ru'))) {
  $_SESSION['lang'] = $lang;
} else {
  $lang = 'bg';
}

$t = array(
  'bg' => array(
    'title' => 'Забравена парола',
    'subtitle' => 'Въведи имейл адреса си за възстановяване',
    'email' => 'Имейл адрес',
    'btn' => 'Изпрати линк',
    'back' => 'Назад към вход',
    'success' => 'Проверете имейла си! Изпратихме ви линк за възстановяване.',
    'error_email' => 'Невалиден имейл адрес.',
    'error_notfound' => 'Този имейл не е регистриран.',
    'error_system' => 'Системна грешка. Опитайте по-късно.',
  ),
  'en' => array(
    'title' => 'Forgot Password',
    'subtitle' => 'Enter your email to reset password',
    'email' => 'Email address',
    'btn' => 'Send Link',
    'back' => 'Back to login',
    'success' => 'Check your email! We sent you a reset link.',
    'error_email' => 'Invalid email address.',
    'error_notfound' => 'This email is not registered.',
    'error_system' => 'System error. Try again later.',
  ),
  'ru' => array(
    'title' => 'Забыли пароль',
    'subtitle' => 'Введите email для восстановления',
    'email' => 'Email адрес',
    'btn' => 'Отправить ссылку',
    'back' => 'Назад ко входу',
    'success' => 'Проверьте почту! Мы отправили вам ссылку.',
    'error_email' => 'Неверный email адрес.',
    'error_notfound' => 'Этот email не зарегистрирован.',
    'error_system' => 'Системная ошибка. Попробуйте позже.',
  ),
);

$tr = $t[$lang];
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tr['title']; ?> – Office Manager</title>
    <style>
        body{margin:0;padding:0;background:#1a1a1a;color:#e5e5e5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center}
        .forgot-container{width:100%;max-width:450px;padding:20px}
        .forgot-card{background:#2a2a2a;border:1px solid #3a3a3a;border-radius:12px;padding:40px 30px;box-shadow:0 4px 20px rgba(0,0,0,.3)}
        .forgot-logo{text-align:center;margin-bottom:30px}
        .forgot-logo-icon{width:64px;height:64px;background:linear-gradient(135deg,#D4AF37,#C5A028);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:28px;font-weight:bold;color:#1a1a1a;box-shadow:0 0 0 3px rgba(212,175,55,.3)}
        .forgot-logo-title{font-size:28px;font-weight:300;color:#e5e5e5;margin-top:16px;margin-bottom:0}
        .forgot-subtitle{text-align:center;font-size:14px;color:#999;margin-bottom:30px;margin-top:8px}
        .forgot-input{width:100%;background:#1a1a1a;border:1px solid #3a3a3a;padding:14px 16px;color:#e5e5e5;border-radius:8px;margin-bottom:16px;font-size:15px;font-family:inherit;box-sizing:border-box}
        .forgot-input:focus{outline:0;border-color:#D4AF37;box-shadow:0 0 0 3px rgba(212,175,55,.1)}
        .forgot-input::placeholder{color:#666}
        .forgot-btn{width:100%;background:linear-gradient(135deg,#D4AF37,#C5A028);color:#1a1a1a;padding:14px;border-radius:8px;border:none;font-size:16px;cursor:pointer;transition:.2s;font-family:inherit;font-weight:600}
        .forgot-btn:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(212,175,55,.3)}
        .forgot-footer{text-align:center;margin-top:24px;font-size:14px;color:#666}
        .forgot-footer a{color:#D4AF37;text-decoration:none;font-weight:500}
        .forgot-footer a:hover{text-decoration:underline}
        .error-message{background:rgba(248,113,113,.1);border:1px solid #f87171;color:#f87171;padding:12px;border-radius:8px;margin-bottom:20px;font-size:14px;text-align:center}
        .success-message{background:rgba(34,197,94,.1);border:1px solid #22c55e;color:#22c55e;padding:12px;border-radius:8px;margin-bottom:20px;font-size:14px;text-align:center}
        .lang-switcher{position:absolute;top:24px;right:24px;display:flex;gap:8px}
        .lang-btn{width:40px;height:28px;border-radius:6px;border:2px solid transparent;cursor:pointer;transition:.2s;text-decoration:none;overflow:hidden;position:relative}
        .lang-btn:hover{transform:scale(1.05)}
        .lang-btn.active{border-color:#D4AF37;box-shadow:0 0 0 2px rgba(212,175,55,.2)}
        .flag-bg{background:linear-gradient(to bottom,#FFF 0%,#FFF 33.33%,#00966E 33.33%,#00966E 66.66%,#D62612 66.66%,#D62612 100%)}
        .flag-en{background:#012169;position:relative}
        .flag-en::before{content:'';position:absolute;top:0;left:0;right:0;bottom:0;background:linear-gradient(to bottom,transparent 40%,#FFF 40%,#FFF 60%,transparent 60%),linear-gradient(to right,transparent 40%,#FFF 40%,#FFF 60%,transparent 60%)}
        .flag-en::after{content:'';position:absolute;top:0;left:0;right:0;bottom:0;background:linear-gradient(to bottom,transparent 45%,#C8102E 45%,#C8102E 55%,transparent 55%),linear-gradient(to right,transparent 45%,#C8102E 45%,#C8102E 55%,transparent 55%)}
        .flag-ru{background:linear-gradient(to bottom,#FFF 0%,#FFF 33.33%,#0039A6 33.33%,#0039A6 66.66%,#D52B1E 66.66%,#D52B1E 100%)}
        @media (max-width:768px){
            .forgot-container{max-width:340px}
            .forgot-card{padding:30px 20px}
            .lang-switcher{top:16px;right:16px}
        }
    </style>
</head>
<body>
<div class="lang-switcher">
    <a href="?lang=bg" class="lang-btn flag-bg <?php echo ($lang === 'bg') ? 'active' : ''; ?>" title="Български"></a>
    <a href="?lang=en" class="lang-btn flag-en <?php echo ($lang === 'en') ? 'active' : ''; ?>" title="English"></a>
    <a href="?lang=ru" class="lang-btn flag-ru <?php echo ($lang === 'ru') ? 'active' : ''; ?>" title="Русский"></a>
</div>

<div class="forgot-container">
    <div class="forgot-card">
        <div class="forgot-logo">
            <div class="forgot-logo-icon">OM</div>
            <h1 class="forgot-logo-title">Office Manager</h1>
        </div>
        <p class="forgot-subtitle"><?php echo $tr['subtitle']; ?></p>
        
        <?php if(isset($_GET['success'])): ?>
            <div class="success-message">✓ <?php echo $tr['success']; ?></div>
        <?php endif; ?>
        
        <?php if(isset($_GET['error'])): ?>
            <div class="error-message">
                <?php
                    $error = htmlspecialchars($_GET['error']);
                    if ($error === 'email') echo $tr['error_email'];
                    elseif ($error === 'notfound') echo $tr['error_notfound'];
                    else echo $tr['error_system'];
                ?>
            </div>
        <?php endif; ?>
        
        <?php if(!isset($_GET['success'])): ?>
        <form method="POST" action="backend/api/auth/forgot-password-process.php">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token'];?>">
            <input type="hidden" name="lang" value="<?php echo $lang;?>">
            
            <input type="email" name="email" class="forgot-input" placeholder="<?php echo $tr['email']; ?>" required>
            
            <button type="submit" class="forgot-btn"><?php echo $tr['btn']; ?></button>
        </form>
        <?php endif; ?>
        
        <div class="forgot-footer">
            <a href="login.php?lang=<?php echo $lang; ?>"><?php echo $tr['back']; ?></a>
        </div>
    </div>
</div>
</body>
</html>
