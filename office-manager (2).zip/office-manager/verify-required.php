<?php
session_start();

// Get language from session
$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'bg';

// Translations
$t = array(
    'bg' => array(
        'title' => 'Потвърди имейл адреса си',
        'message' => 'Твоят акаунт не е активиран. Провери имейла си и кликни на линка за потвърждение.',
        'check_spam' => 'Ако не виждаш имейла, провери Spam папката.',
        'logout' => 'Изход',
    ),
    'en' => array(
        'title' => 'Verify your email',
        'message' => 'Your account is not activated. Check your email and click the verification link.',
        'check_spam' => 'If you don\'t see the email, check your Spam folder.',
        'logout' => 'Logout',
    ),
    'ru' => array(
        'title' => 'Подтвердите email',
        'message' => 'Ваш аккаунт не активирован. Проверьте почту и нажмите на ссылку подтверждения.',
        'check_spam' => 'Если не видите письмо, проверьте папку Спам.',
        'logout' => 'Выход',
    ),
);

$tr = $t[$lang];
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tr['title']; ?> - Office Manager</title>
    <style>
        body{margin:0;padding:0;background:#1a1a1a;color:#e5e5e5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center}
        .verify-container{width:100%;max-width:500px;padding:20px}
        .verify-card{background:#2a2a2a;border:1px solid #3a3a3a;border-radius:12px;padding:40px 30px;box-shadow:0 4px 20px rgba(0,0,0,.3);text-align:center}
        .verify-logo{width:64px;height:64px;background:linear-gradient(135deg,#D4AF37,#C5A028);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:28px;font-weight:bold;color:#1a1a1a;box-shadow:0 0 0 3px rgba(212,175,55,.3);margin-bottom:24px}
        h1{font-size:24px;font-weight:600;margin:0 0 16px;color:#e5e5e5}
        .icon{font-size:64px;margin-bottom:20px;color:#D4AF37}
        .message{background:rgba(212,175,55,.1);border:1px solid #D4AF37;color:#D4AF37;padding:20px;border-radius:8px;margin:24px 0;font-size:16px;line-height:1.6}
        .info{font-size:14px;color:#999;margin:16px 0}
        .logout-btn{display:inline-block;margin-top:24px;padding:12px 24px;background:#2a2a2a;border:1px solid #3a3a3a;color:#e5e5e5;text-decoration:none;border-radius:8px;font-size:14px;transition:.2s}
        .logout-btn:hover{border-color:#D4AF37;background:#1a1a1a}
        @media (max-width:768px){
            .verify-container{max-width:340px}
            .verify-card{padding:30px 20px}
        }
    </style>
</head>
<body>
<div class="verify-container">
    <div class="verify-card">
        <div class="verify-logo">OM</div>
        <div class="icon">📧</div>
        <h1><?php echo $tr['title']; ?></h1>
        <div class="message">
            <?php echo $tr['message']; ?>
        </div>
        <p class="info"><?php echo $tr['check_spam']; ?></p>
        <a href="backend/api/auth/logout.php" class="logout-btn">
            <?php echo $tr['logout']; ?>
        </a>
    </div>
</div>
</body>
</html>
