<?php
require_once __DIR__ . '/backend/lib/auth_guard.php';
require_once __DIR__ . '/backend/lib/roles.php';
om_require_login();

// Само Admin и PM могат да виждат тази страница
require_admin_or_pm();

require_once __DIR__ . '/backend/config/database.php';

$lang = $_SESSION['lang'] ?? 'bg';
$current_user_id = $_SESSION['user_id'];
$current_role = get_user_role();

// Вземи всички потребители от workspace
$workspace_id = $_SESSION['workspace_id'];
$users = array();

try {
    $db = get_db_connection();
    $stmt = $db->prepare("
        SELECT 
            u.id,
            u.full_name,
            u.email,
            u.status,
            u.created_at,
            wm.role,
            wm.is_active
        FROM users u
        INNER JOIN workspace_members wm ON u.id = wm.user_id
        WHERE wm.workspace_id = ?
        ORDER BY wm.role ASC, u.full_name ASC
    ");
    $stmt->execute(array($workspace_id));
    $users = $stmt->fetchAll();
} catch (Exception $e) {
    error_log("Users fetch error: " . $e->getMessage());
}

$t = array(
  'bg' => array(
    'title' => 'Управление на потребители',
    'subtitle' => 'Управление на екип и роли',
    'name' => 'Име',
    'email' => 'Email',
    'role' => 'Роля',
    'status' => 'Статус',
    'actions' => 'Действия',
    'role_admin' => 'Администратор',
    'role_pm' => 'Мениджър',
    'role_accountant' => 'Счетоводител',
    'role_worker' => 'Служител',
    'status_active' => 'Активен',
    'status_suspended' => 'Спрян',
    'status_archived' => 'Архивиран',
    'btn_deactivate' => 'Деактивирай',
    'btn_activate' => 'Активирай',
    'btn_archive' => 'Архивирай',
    'btn_delete' => 'Изтрий',
    'btn_view' => 'Преглед',
    'confirm_deactivate' => 'Сигурни ли сте, че искате да деактивирате този потребител?',
    'confirm_archive' => 'Сигурни ли сте, че искате да архивирате този потребител?',
    'you' => 'Вие',
  ),
  'en' => array(
    'title' => 'User Management',
    'subtitle' => 'Manage team and roles',
    'name' => 'Name',
    'email' => 'Email',
    'role' => 'Role',
    'status' => 'Status',
    'actions' => 'Actions',
    'role_admin' => 'Administrator',
    'role_pm' => 'Manager',
    'role_accountant' => 'Accountant',
    'role_worker' => 'Employee',
    'status_active' => 'Active',
    'status_suspended' => 'Suspended',
    'status_archived' => 'Archived',
    'btn_deactivate' => 'Deactivate',
    'btn_activate' => 'Activate',
    'btn_archive' => 'Archive',
    'btn_delete' => 'Delete',
    'btn_view' => 'View',
    'confirm_deactivate' => 'Are you sure you want to deactivate this user?',
    'confirm_archive' => 'Are you sure you want to archive this user?',
    'you' => 'You',
  ),
  'ru' => array(
    'title' => 'Управление пользователями',
    'subtitle' => 'Управление командой и ролями',
    'name' => 'Имя',
    'email' => 'Email',
    'role' => 'Роль',
    'status' => 'Статус',
    'actions' => 'Действия',
    'role_admin' => 'Администратор',
    'role_pm' => 'Менеджер',
    'role_accountant' => 'Бухгалтер',
    'role_worker' => 'Сотрудник',
    'status_active' => 'Активен',
    'status_suspended' => 'Приостановлен',
    'status_archived' => 'Архивирован',
    'btn_deactivate' => 'Деактивировать',
    'btn_activate' => 'Активировать',
    'btn_archive' => 'Архивировать',
    'btn_delete' => 'Удалить',
    'btn_view' => 'Просмотр',
    'confirm_deactivate' => 'Вы уверены, что хотите деактивировать этого пользователя?',
    'confirm_archive' => 'Вы уверены, что хотите архивировать этого пользователя?',
    'you' => 'Вы',
  ),
);

$tr = $t[$lang];

// Role labels
$role_labels = array(
    'admin' => $tr['role_admin'],
    'pm' => $tr['role_pm'],
    'accountant' => $tr['role_accountant'],
    'worker' => $tr['role_worker'],
);

// Status labels
$status_labels = array(
    'active' => $tr['status_active'],
    'suspended' => $tr['status_suspended'],
    'archived' => $tr['status_archived'],
);
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tr['title']; ?> - Office Manager</title>
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{background:#1a1a1a;color:#e5e5e5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;min-height:100vh;padding:20px 20px 100px}
        .container{max-width:1200px;margin:0 auto}
        .header{text-align:center;margin-bottom:48px;padding-top:60px}
        .logo{width:64px;height:64px;background:linear-gradient(135deg,#D4AF37,#C5A028);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:28px;font-weight:bold;color:#1a1a1a;box-shadow:0 0 0 3px rgba(212,175,55,.3);margin-bottom:24px}
        h1{font-size:32px;font-weight:300;margin-bottom:12px}
        .subtitle{color:#999;font-size:16px}
        .table-container{background:#2a2a2a;border:1px solid #3a3a3a;border-radius:12px;overflow:hidden}
        table{width:100%;border-collapse:collapse}
        thead{background:#1a1a1a;border-bottom:2px solid #D4AF37}
        th{padding:16px;text-align:left;font-weight:600;font-size:14px;color:#D4AF37}
        td{padding:16px;border-bottom:1px solid #3a3a3a;font-size:14px}
        tr:last-child td{border-bottom:none}
        tbody tr:hover{background:#333}
        .badge{display:inline-block;padding:4px 12px;border-radius:12px;font-size:12px;font-weight:600}
        .badge-admin{background:rgba(212,175,55,.2);color:#D4AF37;border:1px solid #D4AF37}
        .badge-pm{background:rgba(59,130,246,.2);color:#3b82f6;border:1px solid #3b82f6}
        .badge-accountant{background:rgba(34,197,94,.2);color:#22c55e;border:1px solid #22c55e}
        .badge-worker{background:rgba(156,163,175,.2);color:#9ca3af;border:1px solid #9ca3af}
        .badge-active{background:rgba(34,197,94,.2);color:#22c55e;border:1px solid #22c55e}
        .badge-suspended{background:rgba(251,146,60,.2);color:#fb923c;border:1px solid #fb923c}
        .badge-archived{background:rgba(107,114,128,.2);color:#6b7280;border:1px solid #6b7280}
        .btn-small{padding:6px 12px;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;transition:.2s;border:none;text-decoration:none;display:inline-block;margin-right:8px}
        .btn-primary{background:linear-gradient(135deg,#D4AF37,#C5A028);color:#1a1a1a}
        .btn-primary:hover{transform:translateY(-1px)}
        .btn-danger{background:#ef4444;color:#fff}
        .btn-danger:hover{background:#dc2626}
        .btn-secondary{background:#2a2a2a;border:1px solid #3a3a3a;color:#e5e5e5}
        .btn-secondary:hover{border-color:#D4AF37}
        .you-indicator{color:#D4AF37;font-size:12px;margin-left:8px}
        @media (max-width:768px){
            .header{padding-top:80px}
            table{font-size:12px}
            th,td{padding:12px 8px}
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="logo">OM</div>
        <h1><?php echo $tr['title']; ?></h1>
        <p class="subtitle"><?php echo $tr['subtitle']; ?></p>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th><?php echo $tr['name']; ?></th>
                    <th><?php echo $tr['email']; ?></th>
                    <th><?php echo $tr['role']; ?></th>
                    <th><?php echo $tr['status']; ?></th>
                    <th><?php echo $tr['actions']; ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td>
                        <?php echo htmlspecialchars($user['full_name']); ?>
                        <?php if ($user['id'] == $current_user_id): ?>
                            <span class="you-indicator">(<?php echo $tr['you']; ?>)</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td>
                        <span class="badge badge-<?php echo $user['role']; ?>">
                            <?php echo $role_labels[$user['role']]; ?>
                        </span>
                    </td>
                    <td>
                        <span class="badge badge-<?php echo $user['status']; ?>">
                            <?php echo $status_labels[$user['status']]; ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($user['id'] != $current_user_id): ?>
                            <?php if (can_deactivate_user($user['id'])): ?>
                                <?php if ($user['status'] === 'active'): ?>
                                    <button onclick="deactivateUser(<?php echo $user['id']; ?>)" class="btn-small btn-danger">
                                        <?php echo $tr['btn_deactivate']; ?>
                                    </button>
                                <?php elseif ($user['status'] === 'suspended'): ?>
                                    <?php if (is_admin()): ?>
                                        <button onclick="archiveUser(<?php echo $user['id']; ?>)" class="btn-small btn-secondary">
                                            <?php echo $tr['btn_archive']; ?>
                                        </button>
                                        <button onclick="activateUser(<?php echo $user['id']; ?>)" class="btn-small btn-primary">
                                            <?php echo $tr['btn_activate']; ?>
                                        </button>
                                    <?php elseif ($user['status'] === 'archived'): ?>
                                    <?php if (is_admin()): ?>
                                        <button onclick="deleteUser(<?php echo $user['id']; ?>)" class="btn-small btn-danger">
                                            <?php echo $tr['btn_delete']; ?>
                                        </button>
                                        <button onclick="activateUser(<?php echo $user['id']; ?>)" class="btn-small btn-primary">
                                            <?php echo $tr['btn_activate']; ?>
                                        </button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                   <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function deactivateUser(userId) {
    if (!confirm('<?php echo addslashes($tr['confirm_deactivate']); ?>')) {
        return;
    }
    window.location.href = `/office-manager/backend/api/users/deactivate.php?id=${userId}&lang=<?php echo $lang; ?>`;
}

function activateUser(userId) {
    window.location.href = `/office-manager/backend/api/users/activate.php?id=${userId}&lang=<?php echo $lang; ?>`;
}

function archiveUser(userId) {
    if (!confirm('<?php echo addslashes($tr['confirm_archive']); ?>')) {
        return;
    }
    window.location.href = `/office-manager/backend/api/users/archive.php?id=${userId}&lang=<?php echo $lang; ?>`;
}

function deleteUser(userId) {
    if (!confirm('ВНИМАНИЕ! Това ще изтрие потребителя ЗАВИНАГИ! Сигурни ли сте?')) {
        return;
    }
    window.location.href = `/office-manager/backend/api/users/delete.php?id=${userId}&lang=<?php echo $lang; ?>`;
}
</script>

<?php include __DIR__ . '/components/user-menu.php'; ?>
</body>
</html>