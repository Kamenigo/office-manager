<?php
require_once __DIR__ . '/backend/lib/auth_guard.php';
om_require_login();

// SECURITY: Only admin and pm (manager proekti) can access
$role = $_SESSION['role'] ?? 'worker';
if (!in_array($role, array('admin', 'pm'))) {
    http_response_code(403);
    die('403 Forbidden - Нямате достъп до тази страница');
}

$lang = $_SESSION['lang'] ?? 'bg';
$workspace_id = $_SESSION['workspace_id'] ?? null;

$t = array(
  'bg' => array(
    'title' => 'Настройка на служители',
    'subtitle' => 'Добавете вашия екип',
    'first_name' => 'Първо име',
    'middle_name' => 'Презиме (незадължително)',
    'last_name' => 'Фамилия',
    'position' => 'Позиция',
    'hire_date' => 'Дата на назначаване',
    'contract_type' => 'Тип договор',
    'contract_probation' => '6 месеца изпитателен срок',
    'contract_permanent' => 'Безсрочен',
    'contract_fixed' => 'Срочен',
    'contract_part_time' => 'Непълно работно време',
    'contract_end_date' => 'Край на договор (ако е срочен)',
    'has_driver_license' => 'Има шофьорска книжка',
    'btn_add_employee' => 'Добави служител',
    'btn_continue' => 'Продължи към Dashboard',
    'employees_added' => 'Добавени служители',
    'no_employees' => 'Все още няма добавени служители',
    'edit' => 'Редактирай',
    'delete' => 'Изтрий',
    'yes' => 'Да',
    'no' => 'Не',
  ),
  'en' => array(
    'title' => 'Employee Setup',
    'subtitle' => 'Add your team',
    'first_name' => 'First Name',
    'middle_name' => 'Middle Name (optional)',
    'last_name' => 'Last Name',
    'position' => 'Position',
    'hire_date' => 'Hire Date',
    'contract_type' => 'Contract Type',
    'contract_probation' => '6 months probation',
    'contract_permanent' => 'Permanent',
    'contract_fixed' => 'Fixed-term',
    'contract_part_time' => 'Part-time',
    'contract_end_date' => 'Contract End Date (if fixed-term)',
    'has_driver_license' => 'Has driver license',
    'btn_add_employee' => 'Add Employee',
    'btn_continue' => 'Continue to Dashboard',
    'employees_added' => 'Added Employees',
    'no_employees' => 'No employees added yet',
    'edit' => 'Edit',
    'delete' => 'Delete',
    'yes' => 'Yes',
    'no' => 'No',
  ),
  'ru' => array(
    'title' => 'Настройка сотрудников',
    'subtitle' => 'Добавьте вашу команду',
    'first_name' => 'Имя',
    'middle_name' => 'Отчество (необязательно)',
    'last_name' => 'Фамилия',
    'position' => 'Должность',
    'hire_date' => 'Дата найма',
    'contract_type' => 'Тип контракта',
    'contract_probation' => '6 месяцев испытательный срок',
    'contract_permanent' => 'Бессрочный',
    'contract_fixed' => 'Срочный',
    'contract_part_time' => 'Неполная занятость',
    'contract_end_date' => 'Конец контракта (если срочный)',
    'has_driver_license' => 'Есть водительские права',
    'btn_add_employee' => 'Добавить сотрудника',
    'btn_continue' => 'Перейти к панели',
    'employees_added' => 'Добавленные сотрудники',
    'no_employees' => 'Сотрудники еще не добавлены',
    'edit' => 'Редактировать',
    'delete' => 'Удалить',
    'yes' => 'Да',
    'no' => 'Нет',
  ),
);

$tr = $t[$lang];

// Get existing employees
require_once __DIR__ . '/backend/config/database.php';
$employees = array();
try {
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT * FROM employees WHERE workspace_id = ? AND is_active = 1 ORDER BY created_at DESC");
    $stmt->execute(array($workspace_id));
    $employees = $stmt->fetchAll();
} catch (Exception $e) {
    error_log("Error fetching employees: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tr['title']; ?> - Office Manager</title>
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{background:#1a1a1a;color:#e5e5e5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;min-height:100vh;padding:20px}
        .container{max-width:800px;margin:0 auto}
        .header{text-align:center;margin-bottom:48px}
        .logo{width:64px;height:64px;background:linear-gradient(135deg,#D4AF37,#C5A028);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:28px;font-weight:bold;color:#1a1a1a;box-shadow:0 0 0 3px rgba(212,175,55,.3);margin-bottom:24px}
        h1{font-size:32px;font-weight:300;margin-bottom:12px}
        .subtitle{color:#999;font-size:16px}
        .card{background:#2a2a2a;border:1px solid #3a3a3a;border-radius:12px;padding:32px;margin-bottom:24px}
        .form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px}
        .form-group{margin-bottom:24px}
        .form-group-full{grid-column:1/-1}
        .form-label{display:block;margin-bottom:8px;font-size:14px;font-weight:600;color:#e5e5e5}
        .input{width:100%;background:#1a1a1a;border:1px solid #3a3a3a;padding:12px 16px;color:#e5e5e5;border-radius:8px;font-size:15px;font-family:inherit}
        .input:focus{outline:0;border-color:#D4AF37;box-shadow:0 0 0 3px rgba(212,175,55,.1)}
        .input::placeholder{color:#666}
        select.input{cursor:pointer}
        .checkbox-group{display:flex;align-items:center;gap:8px}
        .checkbox{width:20px;height:20px;cursor:pointer}
        .btn{padding:12px 24px;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;transition:.2s;border:none;text-decoration:none;display:inline-block}
        .btn-primary{background:linear-gradient(135deg,#D4AF37,#C5A028);color:#1a1a1a}
        .btn-primary:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(212,175,55,.3)}
        .btn-secondary{background:#2a2a2a;border:1px solid #3a3a3a;color:#e5e5e5}
        .btn-secondary:hover{border-color:#D4AF37}
        .employees-list{margin-top:32px}
        .employee-item{background:#1a1a1a;border:1px solid #3a3a3a;border-radius:8px;padding:16px;margin-bottom:12px}
        .employee-header{display:flex;justify-content:space-between;align-items:start;margin-bottom:8px}
        .employee-info h4{margin-bottom:4px;color:#e5e5e5}
        .employee-info p{font-size:14px;color:#999;margin-bottom:4px}
        .employee-actions{display:flex;gap:8px}
        .btn-small{padding:6px 12px;font-size:13px}
        .actions{margin-top:32px;text-align:center}
        @media (max-width:768px){
            .form-row{grid-template-columns:1fr}
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="logo">OM</div>
        <h1><?php echo $tr['title']; ?></h1>
        <p class="subtitle"><?php echo $tr['subtitle']; ?></p>
    </div>

    <div class="card">
        <form method="POST" action="backend/api/employees/add-employee.php" id="employeeForm">
            <input type="hidden" name="lang" value="<?php echo $lang; ?>">
            
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label"><?php echo $tr['first_name']; ?></label>
                    <input type="text" name="first_name" class="input" required>
                </div>

                <div class="form-group">
                    <label class="form-label"><?php echo $tr['middle_name']; ?></label>
                    <input type="text" name="middle_name" class="input">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label"><?php echo $tr['last_name']; ?></label>
                    <input type="text" name="last_name" class="input" required>
                </div>

                <div class="form-group">
                    <label class="form-label"><?php echo $tr['position']; ?></label>
                    <input type="text" name="position" class="input">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label"><?php echo $tr['hire_date']; ?></label>
                    <input type="date" name="hire_date" class="input" required>
                </div>

                <div class="form-group">
                    <label class="form-label"><?php echo $tr['contract_type']; ?></label>
                    <select name="contract_type" class="input" required id="contractType">
                        <option value="probation_6m"><?php echo $tr['contract_probation']; ?></option>
                        <option value="permanent"><?php echo $tr['contract_permanent']; ?></option>
                        <option value="fixed_term"><?php echo $tr['contract_fixed']; ?></option>
                        <option value="part_time"><?php echo $tr['contract_part_time']; ?></option>
                    </select>
                </div>
            </div>

            <div class="form-group" id="endDateGroup" style="display:none">
                <label class="form-label"><?php echo $tr['contract_end_date']; ?></label>
                <input type="date" name="contract_end_date" class="input" id="contractEndDate">
            </div>

            <div class="form-group">
                <div class="checkbox-group">
                    <input type="checkbox" name="has_driver_license" value="1" class="checkbox" id="driverLicense">
                    <label for="driverLicense" class="form-label" style="margin:0"><?php echo $tr['has_driver_license']; ?></label>
                </div>
            </div>

            <button type="submit" class="btn btn-primary"><?php echo $tr['btn_add_employee']; ?></button>
        </form>
    </div>

    <?php if (!empty($employees)): ?>
    <div class="employees-list">
        <h3 style="margin-bottom:16px"><?php echo $tr['employees_added']; ?></h3>
        <?php foreach ($employees as $emp): ?>
        <div class="employee-item">
            <div class="employee-header">
                <div class="employee-info">
                    <h4><?php echo htmlspecialchars($emp['first_name'] . ' ' . ($emp['middle_name'] ? $emp['middle_name'] . ' ' : '') . $emp['last_name']); ?></h4>
                    <?php if ($emp['position']): ?>
                        <p><strong><?php echo htmlspecialchars($emp['position']); ?></strong></p>
                    <?php endif; ?>
                    <p>Назначен: <?php echo date('d.m.Y', strtotime($emp['hire_date'])); ?></p>
                    <?php if ($emp['contract_end_date']): ?>
                        <p>Край на договор: <?php echo date('d.m.Y', strtotime($emp['contract_end_date'])); ?></p>
                    <?php endif; ?>
                    <p>Шофьорска книжка: <?php echo $emp['has_driver_license'] ? $tr['yes'] : $tr['no']; ?></p>
                </div>
                <div class="employee-actions">
                    <button class="btn btn-secondary btn-small"><?php echo $tr['edit']; ?></button>
                    <button class="btn btn-secondary btn-small"><?php echo $tr['delete']; ?></button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="actions">
        <a href="dashboard.php?lang=<?php echo $lang; ?>" class="btn btn-primary"><?php echo $tr['btn_continue']; ?></a>
    </div>
</div>

<script>
// Show/hide contract end date based on contract type
document.getElementById('contractType').addEventListener('change', function() {
    const endDateGroup = document.getElementById('endDateGroup');
    const endDateInput = document.getElementById('contractEndDate');
    
    if (this.value === 'fixed_term' || this.value === 'probation_6m') {
        endDateGroup.style.display = 'block';
        endDateInput.required = true;
        
        // Auto-calculate end date for probation (6 months)
        if (this.value === 'probation_6m') {
            const hireDate = document.querySelector('input[name="hire_date"]').value;
            if (hireDate) {
                const date = new Date(hireDate);
                date.setMonth(date.getMonth() + 6);
                endDateInput.value = date.toISOString().split('T')[0];
            }
        }
    } else {
        endDateGroup.style.display = 'none';
        endDateInput.required = false;
        endDateInput.value = '';
    }
});

// Auto-calculate probation end date when hire date changes
document.querySelector('input[name="hire_date"]').addEventListener('change', function() {
    const contractType = document.getElementById('contractType');
    if (contractType.value === 'probation_6m') {
        const date = new Date(this.value);
        date.setMonth(date.getMonth() + 6);
        document.getElementById('contractEndDate').value = date.toISOString().split('T')[0];
    }
});
</script>

<?php include __DIR__ . '/components/user-menu.php'; ?>
</body>
</html>
