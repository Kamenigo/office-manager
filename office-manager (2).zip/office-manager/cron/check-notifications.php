<?php
require_once __DIR__ . '/../backend/config/database.php';

$alert_days = array(14, 7, 3, 1, 0);

function days_until($date) {
    $now = new DateTime();
    $due = new DateTime($date);
    $diff = $now->diff($due);
    return $diff->days * ($diff->invert ? -1 : 1);
}

function create_notification($db, $workspace_id, $user_id, $type, $title, $message, $due_date, $days_remaining) {
    $stmt = $db->prepare("
        SELECT id FROM notifications 
        WHERE user_id = ? AND type = ? AND due_date = ? AND DATE(created_at) = CURDATE()
    ");
    $stmt->execute(array($user_id, $type, $due_date));
    
    if ($stmt->fetch()) {
        return;
    }
    
    $stmt = $db->prepare("
        INSERT INTO notifications 
        (workspace_id, user_id, type, title, message, due_date, days_remaining, is_read, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, 0, NOW())
    ");
    $stmt->execute(array($workspace_id, $user_id, $type, $title, $message, $due_date, $days_remaining));
}

try {
    $db = get_db_connection();
    
    $stmt = $db->query("
        SELECT 
            v.id as vehicle_id,
            v.name as vehicle_name,
            v.registration_number,
            v.workspace_id,
            v.civil_insurance_expiry,
            v.vignette_expiry,
            v.vehicle_inspection_expiry,
            wm.user_id
        FROM vehicles v
        INNER JOIN workspace_members wm ON v.workspace_id = wm.workspace_id
        WHERE v.is_active = 1 AND wm.is_active = 1
    ");
    
    $notifications_created = 0;
    
    while ($vehicle = $stmt->fetch()) {
        $vehicle_info = $vehicle['vehicle_name'] . ' (' . $vehicle['registration_number'] . ')';
        
        if ($vehicle['civil_insurance_expiry']) {
            $days = days_until($vehicle['civil_insurance_expiry']);
            if (in_array($days, $alert_days)) {
                create_notification($db, $vehicle['workspace_id'], $vehicle['user_id'], 'civil_insurance',
                    'ГО застраховка изтича',
                    "ГО застраховка за $vehicle_info изтича след $days дни.",
                    $vehicle['civil_insurance_expiry'], $days);
                $notifications_created++;
            }
        }
        
        if ($vehicle['vignette_expiry']) {
            $days = days_until($vehicle['vignette_expiry']);
            if (in_array($days, $alert_days)) {
                create_notification($db, $vehicle['workspace_id'], $vehicle['user_id'], 'vignette',
                    'Винетка изтича',
                    "Винетка за $vehicle_info изтича след $days дни.",
                    $vehicle['vignette_expiry'], $days);
                $notifications_created++;
            }
        }
        
        if ($vehicle['vehicle_inspection_expiry']) {
            $days = days_until($vehicle['vehicle_inspection_expiry']);
            if (in_array($days, $alert_days)) {
                create_notification($db, $vehicle['workspace_id'], $vehicle['user_id'], 'vehicle_inspection',
                    'Технически преглед изтича',
                    "Технически преглед за $vehicle_info изтича след $days дни.",
                    $vehicle['vehicle_inspection_expiry'], $days);
                $notifications_created++;
            }
        }
    }
    
    echo "SUCCESS: Created $notifications_created notifications\n";
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}