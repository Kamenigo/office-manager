<?php
require_once __DIR__ . '/backend/lib/auth_guard.php';
om_require_login();

$lang = $_SESSION['lang'] ?? 'bg';
$workspace_id = $_SESSION['workspace_id'] ?? null;

$t = array(
  'bg' => array(
    'title' => 'Настройка на транспорт',
    'subtitle' => 'Добавете вашите автомобили',
    'vehicle_name' => 'Име на автомобил',
    'vehicle_name_ph' => 'напр. Mercedes Sprinter',
    'registration' => 'Номер / Регистрация',
    'registration_ph' => 'напр. СА 1234 ВВ',
    'license_category' => 'Категория за шофиране',
    'eco_group' => 'Еко група',
    'eco_group_ph' => 'напр. Euro 5, Еко 4',
    'eco_info' => 'Еко групата се определя по време на годишния технически преглед в пункт за ГТП и важи за влизане в определени зони. Важи от 01.12 до 28.02 всяка година.',
    'btn_add_vehicle' => 'Добави автомобил',
    'btn_continue' => 'Продължи към Dashboard',
    'vehicles_added' => 'Добавени автомобили',
    'no_vehicles' => 'Все още няма добавени автомобили',
    'edit' => 'Редактирай',
    'delete' => 'Изтрий',
  ),
  'en' => array(
    'title' => 'Transport Setup',
    'subtitle' => 'Add your vehicles',
    'vehicle_name' => 'Vehicle Name',
    'vehicle_name_ph' => 'e.g. Mercedes Sprinter',
    'registration' => 'Registration Number',
    'registration_ph' => 'e.g. CA 1234 BB',
    'license_category' => 'Driving License Category',
    'eco_group' => 'Eco Group',
    'eco_group_ph' => 'e.g. Euro 5, Eco 4',
    'eco_info' => 'The eco group is determined during the annual technical inspection at a vehicle inspection station and is valid for entering certain zones. Valid from 01.12 to 28.02 each year.',
    'btn_add_vehicle' => 'Add Vehicle',
    'btn_continue' => 'Continue to Dashboard',
    'vehicles_added' => 'Added Vehicles',
    'no_vehicles' => 'No vehicles added yet',
    'edit' => 'Edit',
    'delete' => 'Delete',
  ),
  'ru' => array(
    'title' => 'Настройка транспорта',
    'subtitle' => 'Добавьте ваши автомобили',
    'vehicle_name' => 'Название автомобиля',
    'vehicle_name_ph' => 'напр. Mercedes Sprinter',
    'registration' => 'Регистрационный номер',
    'registration_ph' => 'напр. CA 1234 BB',
    'license_category' => 'Категория водительских прав',
    'eco_group' => 'Эко группа',
    'eco_group_ph' => 'напр. Euro 5, Эко 4',
    'eco_info' => 'Экологическая группа определяется во время ежегодного технического осмотра на станции техосмотра и действительна для въезда в определенные зоны. Действует с 01.12 по 28.02 каждого года.',
    'btn_add_vehicle' => 'Добавить автомобиль',
    'btn_continue' => 'Перейти к панели',
    'vehicles_added' => 'Добавленные автомобили',
    'no_vehicles' => 'Автомобили еще не добавлены',
    'edit' => 'Редактировать',
    'delete' => 'Удалить',
  ),
);

$tr = $t[$lang];

// Get existing vehicles
require_once __DIR__ . '/backend/config/database.php';
$vehicles = array();
try {
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT * FROM vehicles WHERE workspace_id = ? AND is_active = 1 ORDER BY created_at DESC");
    $stmt->execute(array($workspace_id));
    $vehicles = $stmt->fetchAll();
} catch (Exception $e) {
    error_log("Error fetching vehicles: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tr['title']; ?> - Office Manager</title>
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{background:#1a1a1a;color:#e5e5e5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;min-height:100vh;padding:20px}
        .container{max-width:800px;margin:0 auto}
        .header{text-align:center;margin-bottom:48px}
        .logo{width:64px;height:64px;background:linear-gradient(135deg,#D4AF37,#C5A028);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:28px;font-weight:bold;color:#1a1a1a;box-shadow:0 0 0 3px rgba(212,175,55,.3);margin-bottom:24px}
        h1{font-size:32px;font-weight:300;margin-bottom:12px}
        .subtitle{color:#999;font-size:16px}
        .card{background:#2a2a2a;border:1px solid #3a3a3a;border-radius:12px;padding:32px;margin-bottom:24px}
        .form-group{margin-bottom:24px}
        .form-label{display:flex;align-items:center;gap:8px;margin-bottom:8px;font-size:14px;font-weight:600;color:#e5e5e5}
        .info-icon{display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;background:#3a3a3a;border-radius:50%;font-size:12px;cursor:help;position:relative}
        .info-icon:hover .tooltip{opacity:1;visibility:visible}
        .tooltip{position:absolute;bottom:calc(100% + 8px);left:50%;transform:translateX(-50%);width:280px;background:#2a2a2a;border:1px solid #D4AF37;border-radius:8px;padding:12px;font-size:12px;font-weight:normal;color:#e5e5e5;line-height:1.5;opacity:0;visibility:hidden;transition:.2s;z-index:100;box-shadow:0 4px 12px rgba(0,0,0,.3)}
        .tooltip::after{content:'';position:absolute;top:100%;left:50%;transform:translateX(-50%);border:6px solid transparent;border-top-color:#D4AF37}
        .input{width:100%;background:#1a1a1a;border:1px solid #3a3a3a;padding:12px 16px;color:#e5e5e5;border-radius:8px;font-size:15px;font-family:inherit}
        .input:focus{outline:0;border-color:#D4AF37;box-shadow:0 0 0 3px rgba(212,175,55,.1)}
        .input::placeholder{color:#666}
        select.input{cursor:pointer}
        .btn{padding:12px 24px;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;transition:.2s;border:none;text-decoration:none;display:inline-block}
        .btn-primary{background:linear-gradient(135deg,#D4AF37,#C5A028);color:#1a1a1a}
        .btn-primary:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(212,175,55,.3)}
        .btn-secondary{background:#2a2a2a;border:1px solid #3a3a3a;color:#e5e5e5}
        .btn-secondary:hover{border-color:#D4AF37}
        .vehicles-list{margin-top:32px}
        .vehicle-item{background:#1a1a1a;border:1px solid #3a3a3a;border-radius:8px;padding:16px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center}
        .vehicle-info h4{margin-bottom:4px;color:#e5e5e5}
        .vehicle-info p{font-size:14px;color:#999}
        .vehicle-actions{display:flex;gap:8px}
        .btn-small{padding:6px 12px;font-size:13px}
        .actions{margin-top:32px;text-align:center}
        @media (max-width:768px){
            .vehicle-item{flex-direction:column;align-items:flex-start;gap:12px}
            .vehicle-actions{width:100%;justify-content:flex-end}
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="logo">OM</div>
        <h1><?php echo $tr['title']; ?></h1>
        <p class="subtitle"><?php echo $tr['subtitle']; ?></p>
    </div>

    <div class="card">
        <form method="POST" action="backend/api/transport/add-vehicle.php">
            <input type="hidden" name="lang" value="<?php echo $lang; ?>">
            
            <div class="form-group">
                <label class="form-label"><?php echo $tr['vehicle_name']; ?></label>
                <input type="text" name="name" class="input" placeholder="<?php echo $tr['vehicle_name_ph']; ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label"><?php echo $tr['registration']; ?></label>
                <input type="text" name="registration_number" class="input" placeholder="<?php echo $tr['registration_ph']; ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label"><?php echo $tr['license_category']; ?></label>
                <select name="driving_license_category" class="input" required>
                    <option value="">Избери категория</option>
                    <option value="B">B - Лек автомобил</option>
                    <option value="C">C - Камион</option>
                    <option value="CE">CE - Камион с ремарке</option>
                    <option value="D">D - Автобус</option>
                    <option value="B+E">B+E - Лек автомобил с ремарке</option>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">
                    <?php echo $tr['eco_group']; ?>
                    <span class="info-icon">
                        ⓘ
                        <span class="tooltip"><?php echo $tr['eco_info']; ?></span>
                    </span>
                </label>
                <input type="text" name="eco_group" class="input" placeholder="<?php echo $tr['eco_group_ph']; ?>">
            </div>
<div class="form-group">
    <label class="form-label">ГО застраховка изтича на</label>
    <input type="date" name="civil_insurance_expiry" class="input">
</div>
<div class="form-group">
    <label class="form-label">Винетка изтича на</label>
    <input type="date" name="vignette_expiry" class="input">
</div>
<div class="form-group">
    <label class="form-label">Технически преглед изтича на</label>
    <input type="date" name="vehicle_inspection_expiry" class="input">
</div>
            <button type="submit" class="btn btn-primary"><?php echo $tr['btn_add_vehicle']; ?></button>
        </form>
    </div>

    <?php if (!empty($vehicles)): ?>
    <div class="vehicles-list">
        <h3 style="margin-bottom:16px"><?php echo $tr['vehicles_added']; ?></h3>
        <?php foreach ($vehicles as $vehicle): ?>
        <div class="vehicle-item">
            <div class="vehicle-info">
                <h4><?php echo htmlspecialchars($vehicle['name']); ?></h4>
                <p><?php echo htmlspecialchars($vehicle['registration_number']); ?> • <?php echo htmlspecialchars($vehicle['driving_license_category']); ?> 
                <?php if ($vehicle['eco_group']): ?>
                    • <?php echo htmlspecialchars($vehicle['eco_group']); ?>
                <?php endif; ?>
                </p>
            </div>
            <div class="vehicle-actions">
                <button class="btn btn-secondary btn-small"><?php echo $tr['edit']; ?></button>
                <button class="btn btn-secondary btn-small"><?php echo $tr['delete']; ?></button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="actions">
        <a href="dashboard.php?lang=<?php echo $lang; ?>" class="btn btn-primary"><?php echo $tr['btn_continue']; ?></a>
    </div>
</div>

<?php include __DIR__ . '/components/user-menu.php'; ?>
</body>
</html>
