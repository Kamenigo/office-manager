<?php
session_start();

// Get token and language from URL
$token = isset($_GET['token']) ? trim($_GET['token']) : '';
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'bg';

if (!in_array($lang, array('bg', 'en', 'ru'))) {
    $lang = 'bg';
}

// Translations
$t = array(
    'bg' => array(
        'title' => 'Потвърждаване на имейл',
        'success_title' => '✓ Имейлът е потвърден!',
        'success_message' => 'Твоят акаунт е активиран успешно. Сега можеш да влезеш в системата.',
        'login_btn' => 'Влез в системата',
        'error_title' => '✗ Грешка при потвърждаване',
        'error_invalid' => 'Невалиден или изтекъл линк за потвърждение.',
        'error_expired' => 'Линкът е изтекъл. Моля, поискай нов линк.',
        'error_already' => 'Този имейл вече е потвърден.',
        'error_notfound' => 'Потребителят не е намерен.',
        'register_link' => 'Регистрирай се отново',
    ),
    'en' => array(
        'title' => 'Email Verification',
        'success_title' => '✓ Email Verified!',
        'success_message' => 'Your account has been activated successfully. You can now login.',
        'login_btn' => 'Login',
        'error_title' => '✗ Verification Error',
        'error_invalid' => 'Invalid or expired verification link.',
        'error_expired' => 'Link has expired. Please request a new one.',
        'error_already' => 'This email is already verified.',
        'error_notfound' => 'User not found.',
        'register_link' => 'Register again',
    ),
    'ru' => array(
        'title' => 'Подтверждение Email',
        'success_title' => '✓ Email Подтвержден!',
        'success_message' => 'Ваш аккаунт успешно активирован. Теперь вы можете войти.',
        'login_btn' => 'Войти',
        'error_title' => '✗ Ошибка Подтверждения',
        'error_invalid' => 'Неверная или истекшая ссылка подтверждения.',
        'error_expired' => 'Ссылка истекла. Пожалуйста, запросите новую.',
        'error_already' => 'Этот email уже подтвержден.',
        'error_notfound' => 'Пользователь не найден.',
        'register_link' => 'Зарегистрироваться снова',
    ),
);

$tr = $t[$lang];

$success = false;
$error_message = '';

// Process verification if token is provided
if (!empty($token)) {
    require_once __DIR__ . '/backend/config/database.php';
    
    try {
        $db = get_db_connection();
        
        // Find user by token
        $stmt = $db->prepare("
            SELECT id, email, is_email_verified, email_verify_expires_at 
            FROM users 
            WHERE email_verify_token = ?
            LIMIT 1
        ");
        $stmt->execute(array($token));
        $user = $stmt->fetch();
        
        if (!$user) {
            $error_message = $tr['error_notfound'];
        } elseif ($user['is_email_verified'] == 1) {
            $error_message = $tr['error_already'];
        } elseif (strtotime($user['email_verify_expires_at']) < time()) {
            $error_message = $tr['error_expired'];
        } else {
            // Verify the email
            $stmt = $db->prepare("
                UPDATE users 
                SET is_email_verified = 1, 
                    email_verify_token = NULL,
                    email_verify_expires_at = NULL
                WHERE id = ?
            ");
            $stmt->execute(array($user['id']));
            
            $success = true;
        }
        
    } catch (Exception $e) {
        error_log("Email verification error: " . $e->getMessage());
        $error_message = $tr['error_invalid'];
    }
} else {
    $error_message = $tr['error_invalid'];
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tr['title']; ?> - Office Manager</title>
    <style>
        body{margin:0;padding:0;background:#1a1a1a;color:#e5e5e5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center}
        .verify-container{width:100%;max-width:500px;padding:20px}
        .verify-card{background:#2a2a2a;border:1px solid #3a3a3a;border-radius:12px;padding:40px 30px;box-shadow:0 4px 20px rgba(0,0,0,.3);text-align:center}
        .verify-logo{width:64px;height:64px;background:linear-gradient(135deg,#D4AF37,#C5A028);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:28px;font-weight:bold;color:#1a1a1a;box-shadow:0 0 0 3px rgba(212,175,55,.3);margin-bottom:24px}
        h1{font-size:24px;font-weight:600;margin:0 0 16px;color:#e5e5e5}
        .success-icon{font-size:64px;margin-bottom:20px}
        .success-message{background:rgba(34,197,94,.1);border:1px solid #22c55e;color:#22c55e;padding:20px;border-radius:8px;margin:24px 0;font-size:16px;line-height:1.6}
        .error-message{background:rgba(248,113,113,.1);border:1px solid #f87171;color:#f87171;padding:20px;border-radius:8px;margin:24px 0;font-size:16px;line-height:1.6}
        .verify-btn{display:inline-block;width:100%;background:linear-gradient(135deg,#D4AF37,#C5A028);color:#1a1a1a;padding:14px 24px;border-radius:8px;border:none;font-size:16px;font-weight:600;text-decoration:none;margin-top:24px;box-sizing:border-box;transition:.2s}
        .verify-btn:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(212,175,55,.3)}
        .secondary-link{display:inline-block;margin-top:16px;color:#D4AF37;text-decoration:none;font-size:14px}
        .secondary-link:hover{text-decoration:underline}
        @media (max-width:768px){
            .verify-container{max-width:340px}
            .verify-card{padding:30px 20px}
        }
    </style>
</head>
<body>
<div class="verify-container">
    <div class="verify-card">
        <div class="verify-logo">OM</div>
        
        <?php if ($success): ?>
            <div class="success-icon">✓</div>
            <h1><?php echo $tr['success_title']; ?></h1>
            <div class="success-message">
                <?php echo $tr['success_message']; ?>
            </div>
            <a href="login.php?lang=<?php echo $lang; ?>" class="verify-btn">
                <?php echo $tr['login_btn']; ?>
            </a>
        <?php else: ?>
            <div class="success-icon" style="color:#f87171">✗</div>
            <h1><?php echo $tr['error_title']; ?></h1>
            <div class="error-message">
                <?php echo $error_message; ?>
            </div>
            <a href="register.php?lang=<?php echo $lang; ?>" class="secondary-link">
                <?php echo $tr['register_link']; ?>
            </a>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
