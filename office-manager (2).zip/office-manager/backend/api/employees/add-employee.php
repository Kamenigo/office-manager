<?php
session_start();

// Check POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('ERROR: POST only');
}

// Must be logged in
if (empty($_SESSION['user_id']) || empty($_SESSION['workspace_id'])) {
    header('Location: /office-manager/login.php');
    exit;
}

// SECURITY: Only admin and pm can add employees
$role = $_SESSION['role'] ?? 'worker';
if (!in_array($role, array('admin', 'pm'))) {
    http_response_code(403);
    die('403 Forbidden');
}

$workspace_id = $_SESSION['workspace_id'];
$lang = isset($_POST['lang']) ? $_POST['lang'] : 'bg';

// Get data
$first_name = isset($_POST['first_name']) ? trim($_POST['first_name']) : '';
$middle_name = isset($_POST['middle_name']) ? trim($_POST['middle_name']) : null;
$last_name = isset($_POST['last_name']) ? trim($_POST['last_name']) : '';
$position = isset($_POST['position']) ? trim($_POST['position']) : null;
$hire_date = isset($_POST['hire_date']) ? $_POST['hire_date'] : '';
$contract_type = isset($_POST['contract_type']) ? $_POST['contract_type'] : 'probation_6m';
$contract_end_date = isset($_POST['contract_end_date']) ? $_POST['contract_end_date'] : null;
$has_driver_license = isset($_POST['has_driver_license']) ? 1 : 0;

// Validate
if (empty($first_name) || empty($last_name) || empty($hire_date)) {
    header("Location: /office-manager/setup-employees.php?error=required&lang=$lang");
    exit;
}

// Database
require_once __DIR__ . '/../../config/database.php';

try {
    $db = get_db_connection();
    
    // Insert employee
    $stmt = $db->prepare("
        INSERT INTO employees 
        (workspace_id, first_name, middle_name, last_name, position, hire_date, contract_type, contract_end_date, has_driver_license, is_active, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())
    ");
    $stmt->execute(array(
        $workspace_id,
        $first_name,
        $middle_name,
        $last_name,
        $position,
        $hire_date,
        $contract_type,
        $contract_end_date,
        $has_driver_license
    ));
    
    header("Location: /office-manager/setup-employees.php?success=1&lang=$lang");
    exit;
    
} catch (Exception $e) {
    error_log("Add employee error: " . $e->getMessage());
    header("Location: /office-manager/setup-employees.php?error=system&lang=$lang");
    exit;
}
