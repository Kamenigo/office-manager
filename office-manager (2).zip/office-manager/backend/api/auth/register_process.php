<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Check if this is a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('ERROR: This page only accepts POST requests.');
}

// CSRF Protection
if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    header('Location: ../../../register.php?error=invalid_request');
    exit;
}

// Get language
$lang = isset($_POST['lang']) ? $_POST['lang'] : 'bg';

// Validate inputs
if (empty($_POST['name']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['confirm_password'])) {
    header("Location: ../../../register.php?error=empty&lang=$lang");
    exit;
}

$name = trim($_POST['name']);
$email = trim($_POST['email']);
$lang = isset($_POST['lang']) ? $_POST['lang'] : 'bg';
$phone = isset($_POST['phone']) ? trim($_POST['phone']) : null;
// Validate phone (only digits, +, -, spaces, parentheses)
if ($phone && !preg_match('/^[0-9+\s\-()]+$/', $phone)) {
    header("Location: /office-manager/register.php?error=invalid_phone&lang=$lang");
    exit;
}
$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];

// Validate email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: ../../../register.php?error=invalid_email&lang=$lang");
    exit;
}

// Validate password length
if (strlen($password) < 6) {
    header("Location: ../../../register.php?error=short&lang=$lang");
    exit;
}

// Validate password strength (must contain letters and numbers)
if (!preg_match('/[a-zA-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
    header("Location: ../../../register.php?error=weak&lang=$lang");
    exit;
}

// Check if passwords match
if ($password !== $confirm_password) {
    header("Location: ../../../register.php?error=mismatch&lang=$lang");
    exit;
}

// Database connection
require_once __DIR__ . '/../../config/database.php';

try {
    $db = get_db_connection();
    
    // Check if email already exists
    $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute(array($email));
    if ($stmt->fetch()) {
        header("Location: ../../../register.php?error=exists&lang=$lang");
        exit;
    }
    
    // Generate verification token (64 characters)
    $verification_token = bin2hex(random_bytes(32));
    
    // Set expiry (24 hours from now)
    $expires_at = date('Y-m-d H:i:s', strtotime('+24 hours'));
    
    // Hash password
    $password_hash = password_hash($password, PASSWORD_BCRYPT);
    
    // Insert user
    $stmt = $db->prepare("
        INSERT INTO users 
(email, password_hash, full_name, phone, preferred_lang, is_email_verified, email_verify_token, email_verify_expires_at, created_at) 
VALUES (?, ?, ?, ?, ?, 0, ?, ?, NOW())
    ");
    $stmt->execute(array($email, $password_hash, $name, $phone, $lang, $verification_token, $expires_at));
    
    // Send verification email
    require_once __DIR__ . '/../../lib/email.php';
    $email_sent = send_verification_email($email, $name, $verification_token, $lang);
    
    if (!$email_sent) {
        error_log("Failed to send verification email to: $email");
        // Continue anyway - user can request new verification link later
    }
    
    // Redirect to success page
    header("Location: ../../../register.php?success=1&lang=$lang");
    exit;
    
} catch (Exception $e) {
    error_log("Registration error: " . $e->getMessage());
    header("Location: ../../../register.php?error=system&lang=$lang");
    exit;
}
