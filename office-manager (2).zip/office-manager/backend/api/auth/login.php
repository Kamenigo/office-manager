<?php
require_once __DIR__ . '/../../config/database.php';

session_start();

// Only POST allowed
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  exit('Method not allowed');
}

$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

// Validation
if (empty($email) || empty($password)) {
  header('Location: /office-manager/login.php?error=required');
  exit;
}

$pdo = get_db_connection();

// Find user by email
$stmt = $pdo->prepare("
  SELECT id, email, password_hash, full_name, is_email_verified, preferred_lang
  FROM users
  WHERE email = ?
  LIMIT 1
");
$stmt->execute([$email]);
$user = $stmt->fetch();

// Check credentials
if (!$user || !password_verify($password, $user['password_hash'])) {
  header('Location: /office-manager/login.php?error=invalid');
  exit;
}
// SECURITY: Email verification is MANDATORY - CHECK BEFORE SESSION
if ($user['is_email_verified'] != 1) {
  header('Location: /office-manager/verify-required.php');
  exit;
}
// Set session
$_SESSION['user_id'] = $user['id'];
$_SESSION['email'] = $user['email'];
$_SESSION['full_name'] = $user['full_name'];
$_SESSION['is_email_verified'] = (int)$user['is_email_verified'];
$_SESSION['lang'] = $user['preferred_lang'];

// Check workspace membership
$stmt = $pdo->prepare("
  SELECT wm.workspace_id, wm.role, w.name as workspace_name
  FROM workspace_members wm
  JOIN workspaces w ON w.id = wm.workspace_id
  WHERE wm.user_id = ? AND wm.is_active = 1
  LIMIT 1
");
$stmt->execute([$user['id']]);
$membership = $stmt->fetch();

// No workspace membership -> onboarding
if (!$membership) {
  $lang = $_SESSION['lang'] ?? 'bg';
header('Location: /office-manager/onboarding.php?lang=' . $lang);
  exit;
}

// Set workspace context
$_SESSION['workspace_id'] = $membership['workspace_id'];
$_SESSION['workspace_name'] = $membership['workspace_name'];
$_SESSION['role'] = $membership['role'];

// Go to dashboard
header('Location: /office-manager/dashboard.php');
exit;
