<?php
session_start();

// Check POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('ERROR: This page only accepts POST requests.');
}

// CSRF Protection
if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    header('Location: ../../../reset-password.php?error=invalid_request');
    exit;
}

// Get data
$token = isset($_POST['token']) ? trim($_POST['token']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
$lang = isset($_POST['lang']) ? $_POST['lang'] : 'bg';

// Validate password length
if (strlen($password) < 6) {
    header("Location: ../../../reset-password.php?token=" . urlencode($token) . "&error=short&lang=$lang");
    exit;
}

// Validate password strength (must contain letters and numbers)
if (!preg_match('/[a-zA-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
    header("Location: ../../../reset-password.php?token=" . urlencode($token) . "&error=weak&lang=$lang");
    exit;
}

// Check if passwords match
if ($password !== $confirm_password) {
    header("Location: ../../../reset-password.php?token=" . urlencode($token) . "&error=mismatch&lang=$lang");
    exit;
}

// Database connection
require_once __DIR__ . '/../../config/database.php';

try {
    $db = get_db_connection();
    
    // Find user by token
    $stmt = $db->prepare("
        SELECT id, password_reset_expires_at 
        FROM users 
        WHERE password_reset_token = ?
        LIMIT 1
    ");
    $stmt->execute(array($token));
    $user = $stmt->fetch();
    
    if (!$user) {
        header("Location: ../../../reset-password.php?token=" . urlencode($token) . "&error=invalid&lang=$lang");
        exit;
    }
    
    // Check if token has expired
    if (strtotime($user['password_reset_expires_at']) < time()) {
        header("Location: ../../../reset-password.php?token=" . urlencode($token) . "&error=expired&lang=$lang");
        exit;
    }
    
    // Hash new password
    $password_hash = password_hash($password, PASSWORD_BCRYPT);
    
    // Update password and clear reset token
    $stmt = $db->prepare("
        UPDATE users 
        SET password_hash = ?,
            password_reset_token = NULL,
            password_reset_expires_at = NULL
        WHERE id = ?
    ");
    $stmt->execute(array($password_hash, $user['id']));
    
    // Redirect to success
    header("Location: ../../../reset-password.php?success=1&lang=$lang");
    exit;
    
} catch (Exception $e) {
    error_log("Password reset error: " . $e->getMessage());
    header("Location: ../../../reset-password.php?token=" . urlencode($token) . "&error=system&lang=$lang");
    exit;
}
