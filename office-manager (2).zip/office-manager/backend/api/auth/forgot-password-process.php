<?php
session_start();

// Check POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('ERROR: This page only accepts POST requests.');
}

// CSRF Protection
if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    header('Location: ../../../forgot-password.php?error=invalid_request');
    exit;
}

// Get language
$lang = isset($_POST['lang']) ? $_POST['lang'] : 'bg';

// Validate email
$email = isset($_POST['email']) ? trim($_POST['email']) : '';

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: ../../../forgot-password.php?error=email&lang=$lang");
    exit;
}

// Database connection
require_once __DIR__ . '/../../config/database.php';

try {
    $db = get_db_connection();
    
    // Check if email exists
    $stmt = $db->prepare("SELECT id, full_name, email FROM users WHERE email = ? LIMIT 1");
    $stmt->execute(array($email));
    $user = $stmt->fetch();
    
    if (!$user) {
        // SECURITY: Don't reveal if email exists or not
        // Redirect to success anyway to prevent email enumeration
        header("Location: ../../../forgot-password.php?success=1&lang=$lang");
        exit;
    }
    
    // Generate reset token (64 characters)
    $reset_token = bin2hex(random_bytes(32));
    
    // Set expiry (1 hour from now)
    $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));
    
    // Update user with reset token
    $stmt = $db->prepare("
        UPDATE users 
        SET password_reset_token = ?, 
            password_reset_expires_at = ?
        WHERE id = ?
    ");
    $stmt->execute(array($reset_token, $expires_at, $user['id']));
    
    // Send password reset email
    require_once __DIR__ . '/../../lib/email-password-reset.php';
    $email_sent = send_password_reset_email($user['email'], $user['full_name'], $reset_token, $lang);
    
    if (!$email_sent) {
        error_log("Failed to send password reset email to: " . $user['email']);
    }
    
    // Always redirect to success (security)
    header("Location: ../../../forgot-password.php?success=1&lang=$lang");
    exit;
    
} catch (Exception $e) {
    error_log("Forgot password error: " . $e->getMessage());
    header("Location: ../../../forgot-password.php?error=system&lang=$lang");
    exit;
}
