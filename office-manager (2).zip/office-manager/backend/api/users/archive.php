<?php
session_start();

require_once __DIR__ . '/../../lib/roles.php';
require_once __DIR__ . '/../../config/database.php';

// Само Admin
require_admin();

$target_user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'bg';

if (!$target_user_id) {
    header("Location: /office-manager/manage-users.php?error=invalid_user&lang=$lang");
    exit;
}

try {
    $db = get_db_connection();
    $db->beginTransaction();
    
    // Архивиране
    $stmt = $db->prepare("UPDATE users SET status = 'archived' WHERE id = ?");
    $stmt->execute(array($target_user_id));
    
    // Audit log
    log_action('archive_user', $target_user_id, 
        array('status' => 'suspended'),
        array('status' => 'archived')
    );
    
    // Одобри заявката ако има такава
    $workspace_id = $_SESSION['workspace_id'];
    $admin_id = $_SESSION['user_id'];
    
    $stmt = $db->prepare("
        UPDATE deactivation_requests 
        SET status = 'approved', approved_by = ?, updated_at = NOW()
        WHERE target_user_id = ? AND workspace_id = ? AND status = 'pending'
    ");
    $stmt->execute(array($admin_id, $target_user_id, $workspace_id));
    
    $db->commit();
    
    header("Location: /office-manager/manage-users.php?success=archived&lang=$lang");
    exit;
    
} catch (Exception $e) {
    if (isset($db)) {
        $db->rollBack();
    }
    error_log("Archive error: " . $e->getMessage());
    header("Location: /office-manager/manage-users.php?error=system&lang=$lang");
    exit;
}
