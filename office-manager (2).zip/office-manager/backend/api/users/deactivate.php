<?php
session_start();

require_once __DIR__ . '/../../lib/roles.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../lib/email.php';

// Must be logged in
if (empty($_SESSION['user_id'])) {
    header('Location: /office-manager/login.php');
    exit;
}

// Get data
$target_user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'bg';

if (!$target_user_id) {
    header("Location: /office-manager/manage-users.php?error=invalid_user&lang=$lang");
    exit;
}

// Проверка на права
if (!can_deactivate_user($target_user_id)) {
    header("Location: /office-manager/manage-users.php?error=no_permission&lang=$lang");
    exit;
}

$current_user_id = $_SESSION['user_id'];
$current_role = get_user_role();
$workspace_id = $_SESSION['workspace_id'];

try {
    $db = get_db_connection();
    $db->beginTransaction();
    
    // Вземи информация за target user
    $stmt = $db->prepare("SELECT full_name, email, status FROM users WHERE id = ?");
    $stmt->execute(array($target_user_id));
    $target_user = $stmt->fetch();
    
    if (!$target_user) {
        throw new Exception("User not found");
    }
    
    // Ако е вече suspended/archived
    if ($target_user['status'] !== 'active') {
        $db->rollBack();
        header("Location: /office-manager/manage-users.php?error=already_suspended&lang=$lang");
        exit;
    }
    
    // ADMIN може да деактивира директно
    if ($current_role === 'admin') {
        // Деактивиране (status = suspended, is_active = 0)
        $stmt = $db->prepare("UPDATE users SET status = 'suspended' WHERE id = ?");
        $stmt->execute(array($target_user_id));
        
        $stmt = $db->prepare("UPDATE workspace_members SET is_active = 0 WHERE user_id = ? AND workspace_id = ?");
        $stmt->execute(array($target_user_id, $workspace_id));
        
        // Audit log
        log_action('suspend_user', $target_user_id, 
            array('status' => 'active'),
            array('status' => 'suspended')
        );
        
        $db->commit();
        
        // Email до потребителя
        send_deactivation_email($target_user['email'], $target_user['full_name'], $lang);
        
        header("Location: /office-manager/manage-users.php?success=deactivated&lang=$lang");
        exit;
    }
    
    // PM създава заявка за одобрение
    if ($current_role === 'pm') {
        // Деактивиране временно
        $stmt = $db->prepare("UPDATE users SET status = 'suspended' WHERE id = ?");
        $stmt->execute(array($target_user_id));
        
        $stmt = $db->prepare("UPDATE workspace_members SET is_active = 0 WHERE user_id = ? AND workspace_id = ?");
        $stmt->execute(array($target_user_id, $workspace_id));
        
        // Създай заявка за одобрение
        $stmt = $db->prepare("
            INSERT INTO deactivation_requests 
            (workspace_id, target_user_id, requested_by, status, created_at)
            VALUES (?, ?, ?, 'pending', NOW())
        ");
        $stmt->execute(array($workspace_id, $target_user_id, $current_user_id));
        $request_id = $db->lastInsertId();
        
        // Audit log
        log_action('request_deactivation', $target_user_id, null, 
            array('request_id' => $request_id, 'requested_by' => $current_user_id)
        );
        
        $db->commit();
        
        // Email до потребителя
        send_deactivation_email($target_user['email'], $target_user['full_name'], $lang);
        
        // Email до всички Admins за одобрение
        send_approval_request_to_admins($workspace_id, $target_user['full_name'], $request_id, $lang);
        
        header("Location: /office-manager/manage-users.php?success=pending_approval&lang=$lang");
        exit;
    }
    
    // Не трябва да стигнем тук
    $db->rollBack();
    header("Location: /office-manager/manage-users.php?error=unknown&lang=$lang");
    exit;
    
} catch (Exception $e) {
    if (isset($db)) {
        $db->rollBack();
    }
    error_log("Deactivation error: " . $e->getMessage());
    header("Location: /office-manager/manage-users.php?error=system&lang=$lang");
    exit;
}

/**
 * Изпраща email до деактивиран потребител
 */
function send_deactivation_email($email, $name, $lang) {
    $t = array(
        'bg' => array(
            'subject' => 'Вашият акаунт е деактивиран',
            'body' => "Здравейте $name,\n\nВашият акаунт в Office Manager е деактивиран.\n\nАко смятате, че това е грешка, моля свържете се с администратора на вашия workspace.\n\nПоздрави,\nOffice Manager екип"
        ),
        'en' => array(
            'subject' => 'Your account has been deactivated',
            'body' => "Hello $name,\n\nYour account in Office Manager has been deactivated.\n\nIf you believe this is an error, please contact your workspace administrator.\n\nBest regards,\nOffice Manager team"
        ),
        'ru' => array(
            'subject' => 'Ваш аккаунт деактивирован',
            'body' => "Здравствуйте $name,\n\nВаш аккаунт в Office Manager был деактивирован.\n\nЕсли вы считаете, что это ошибка, пожалуйста, свяжитесь с администратором вашего рабочего пространства.\n\nС уважением,\nКоманда Office Manager"
        ),
    );
    
    $tr = $t[$lang];
    send_email($email, $tr['subject'], $tr['body']);
}

/**
 * Изпраща email до Admins за одобрение
 */
function send_approval_request_to_admins($workspace_id, $target_name, $request_id, $lang) {
    global $db;
    
    // Вземи всички Admins
    $stmt = $db->prepare("
        SELECT u.email, u.full_name 
        FROM users u
        INNER JOIN workspace_members wm ON u.id = wm.user_id
        WHERE wm.workspace_id = ? AND wm.role = 'admin' AND wm.is_active = 1
    ");
    $stmt->execute(array($workspace_id));
    $admins = $stmt->fetchAll();
    
    $t = array(
        'bg' => array(
            'subject' => 'Заявка за деактивиране на потребител',
            'body' => "Здравейте,\n\nProject Manager е заявил деактивиране на потребител: $target_name.\n\nПотребителят е временно спрян. За окончателно архивиране, моля одобрете заявката от системата.\n\nПоздрави,\nOffice Manager"
        ),
        'en' => array(
            'subject' => 'User deactivation request',
            'body' => "Hello,\n\nA Project Manager has requested deactivation of user: $target_name.\n\nThe user is temporarily suspended. To permanently archive, please approve the request from the system.\n\nBest regards,\nOffice Manager"
        ),
        'ru' => array(
            'subject' => 'Запрос на деактивацию пользователя',
            'body' => "Здравствуйте,\n\nМенеджер проекта запросил деактивацию пользователя: $target_name.\n\nПользователь временно приостановлен. Для окончательной архивации, пожалуйста, одобрите запрос из системы.\n\nС уважением,\nOffice Manager"
        ),
    );
    
    $tr = $t[$lang];
    
    foreach ($admins as $admin) {
        send_email($admin['email'], $tr['subject'], $tr['body']);
    }
}
