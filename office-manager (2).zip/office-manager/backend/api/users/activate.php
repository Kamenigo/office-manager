<?php
session_start();

require_once __DIR__ . '/../../lib/roles.php';
require_once __DIR__ . '/../../config/database.php';

// Само Admin
require_admin();

$target_user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'bg';

if (!$target_user_id) {
    header("Location: /office-manager/manage-users.php?error=invalid_user&lang=$lang");
    exit;
}

$workspace_id = $_SESSION['workspace_id'];

try {
    $db = get_db_connection();
    $db->beginTransaction();
    
    // Активиране
    $stmt = $db->prepare("UPDATE users SET status = 'active' WHERE id = ?");
    $stmt->execute(array($target_user_id));
    
    $stmt = $db->prepare("UPDATE workspace_members SET is_active = 1 WHERE user_id = ? AND workspace_id = ?");
    $stmt->execute(array($target_user_id, $workspace_id));
    
    // Audit log
    log_action('activate_user', $target_user_id, 
        array('status' => 'suspended'),
        array('status' => 'active')
    );
    
    $db->commit();
    
    header("Location: /office-manager/manage-users.php?success=activated&lang=$lang");
    exit;
    
} catch (Exception $e) {
    if (isset($db)) {
        $db->rollBack();
    }
    error_log("Activation error: " . $e->getMessage());
    header("Location: /office-manager/manage-users.php?error=system&lang=$lang");
    exit;
}
