<?php
session_start();

require_once __DIR__ . '/../../lib/roles.php';
require_once __DIR__ . '/../../config/database.php';

// Само Admin може да изтрива
require_admin();

$target_user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'bg';

if (!$target_user_id) {
    header("Location: /office-manager/manage-users.php?error=invalid_user&lang=$lang");
    exit;
}

try {
    $db = get_db_connection();
    $db->beginTransaction();
    
    // Вземи информация за user
    $stmt = $db->prepare("SELECT full_name, status FROM users WHERE id = ?");
    $stmt->execute(array($target_user_id));
    $target_user = $stmt->fetch();
    
    if (!$target_user) {
        throw new Exception("User not found");
    }
    
    // Може да се изтрива само archived
    if ($target_user['status'] !== 'archived') {
        $db->rollBack();
        header("Location: /office-manager/manage-users.php?error=not_archived&lang=$lang");
        exit;
    }
    
    // ФИЗИЧЕСКО ИЗТРИВАНЕ
    $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute(array($target_user_id));
    
    // Audit log
    log_action('delete_user', $target_user_id, 
        array('name' => $target_user['full_name']),
        null
    );
    
    $db->commit();
    
    header("Location: /office-manager/manage-users.php?success=deleted&lang=$lang");
    exit;
    
} catch (Exception $e) {
    if (isset($db)) {
        $db->rollBack();
    }
    error_log("Delete error: " . $e->getMessage());
    header("Location: /office-manager/manage-users.php?error=system&lang=$lang");
    exit;
}