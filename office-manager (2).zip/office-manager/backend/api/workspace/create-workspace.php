<?php
session_start();

// Check POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('ERROR: This page only accepts POST requests.');
}

// Must be logged in
if (empty($_SESSION['user_id'])) {
    header('Location: /office-manager/login.php');
    exit;
}

// Get data
$workspace_type = isset($_POST['workspace_type']) ? $_POST['workspace_type'] : 'solo';
$modules = isset($_POST['modules']) ? $_POST['modules'] : array();
$lang = isset($_POST['lang']) ? $_POST['lang'] : 'bg';

// Validate
if (empty($modules)) {
    header("Location: /office-manager/select-modules.php?error=no_modules&type=$workspace_type&lang=$lang");
    exit;
}

// Database connection
require_once __DIR__ . '/../../config/database.php';

try {
    $db = get_db_connection();
    
    // Start transaction
    $db->beginTransaction();
    
    // Check if user already has workspace
    $stmt = $db->prepare("
        SELECT workspace_id 
        FROM workspace_members 
        WHERE user_id = ? AND is_active = 1 
        LIMIT 1
    ");
    $stmt->execute(array($_SESSION['user_id']));
    if ($stmt->fetch()) {
        $db->rollBack();
        header('Location: /office-manager/dashboard.php');
        exit;
    }
    
    // Generate workspace name
    $userName = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : 'User';
    $workspaceName = $workspace_type === 'team' 
        ? $userName . "'s Team Workspace" 
        : $userName . "'s Workspace";
    
    // Create workspace
    $stmt = $db->prepare("
        INSERT INTO workspaces (name, type, owner_id, created_at) 
        VALUES (?, ?, ?, NOW())
    ");
    $stmt->execute(array($workspaceName, $workspace_type, $_SESSION['user_id']));
    $workspace_id = $db->lastInsertId();
    
    // Add user as admin member
    $stmt = $db->prepare("
        INSERT INTO workspace_members (workspace_id, user_id, role, is_active, joined_at) 
        VALUES (?, ?, 'admin', 1, NOW())
    ");
    $stmt->execute(array($workspace_id, $_SESSION['user_id']));
    
    // Save selected modules
    foreach ($modules as $module_name) {
        $stmt = $db->prepare("
            INSERT INTO workspace_modules (workspace_id, module_name, is_enabled, created_at) 
            VALUES (?, ?, 1, NOW())
        ");
        $stmt->execute(array($workspace_id, $module_name));
    }
    
    // Commit transaction
    $db->commit();
    
    // Set session workspace data
    $_SESSION['workspace_id'] = $workspace_id;
    $_SESSION['workspace_name'] = $workspaceName;
    $_SESSION['role'] = 'admin';
    
    // Redirect to dashboard
    header('Location: /office-manager/dashboard.php');
    exit;
    
} catch (Exception $e) {
    if (isset($db)) {
        $db->rollBack();
    }
    error_log("Workspace creation error: " . $e->getMessage());
    header("Location: /office-manager/select-modules.php?error=system&type=$workspace_type&lang=$lang");
    exit;
}