<?php
session_start();

// Check POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('ERROR: POST only');
}

// Must be logged in
if (empty($_SESSION['user_id'])) {
    header('Location: /office-manager/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$lang = isset($_POST['lang']) ? $_POST['lang'] : 'bg';

// Get data
$driver_license_number = isset($_POST['driver_license_number']) ? trim($_POST['driver_license_number']) : null;
$car_registration = isset($_POST['car_registration']) ? trim($_POST['car_registration']) : null;
$car_make_model = isset($_POST['car_make_model']) ? trim($_POST['car_make_model']) : null;
$civil_insurance_expiry = isset($_POST['civil_insurance_expiry']) && !empty($_POST['civil_insurance_expiry']) ? $_POST['civil_insurance_expiry'] : null;
$vignette_expiry = isset($_POST['vignette_expiry']) && !empty($_POST['vignette_expiry']) ? $_POST['vignette_expiry'] : null;
$vehicle_inspection_expiry = isset($_POST['vehicle_inspection_expiry']) && !empty($_POST['vehicle_inspection_expiry']) ? $_POST['vehicle_inspection_expiry'] : null;

// Database
require_once __DIR__ . '/../../config/database.php';

try {
    $db = get_db_connection();
    
    // Check if profile exists
    $stmt = $db->prepare("SELECT id FROM user_profiles WHERE user_id = ?");
    $stmt->execute(array($user_id));
    $exists = $stmt->fetch();
    
    if ($exists) {
        // Update existing profile
        $stmt = $db->prepare("
            UPDATE user_profiles 
            SET driver_license_number = ?,
                car_registration = ?,
                car_make_model = ?,
                civil_insurance_expiry = ?,
                vignette_expiry = ?,
                vehicle_inspection_expiry = ?,
                updated_at = NOW()
            WHERE user_id = ?
        ");
        $stmt->execute(array(
            $driver_license_number,
            $car_registration,
            $car_make_model,
            $civil_insurance_expiry,
            $vignette_expiry,
            $vehicle_inspection_expiry,
            $user_id
        ));
    } else {
        // Insert new profile
        $stmt = $db->prepare("
            INSERT INTO user_profiles 
            (user_id, driver_license_number, car_registration, car_make_model, 
             civil_insurance_expiry, vignette_expiry, vehicle_inspection_expiry, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute(array(
            $user_id,
            $driver_license_number,
            $car_registration,
            $car_make_model,
            $civil_insurance_expiry,
            $vignette_expiry,
            $vehicle_inspection_expiry
        ));
    }
    
    header("Location: /office-manager/profile.php?success=1&lang=$lang");
    exit;
    
} catch (Exception $e) {
    error_log("Profile update error: " . $e->getMessage());
    header("Location: /office-manager/profile.php?error=1&lang=$lang");
    exit;
}
