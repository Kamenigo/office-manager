<?php
session_start();

// Check POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('ERROR: POST only');
}

// Must be logged in
if (empty($_SESSION['user_id']) || empty($_SESSION['workspace_id'])) {
    header('Location: /office-manager/login.php');
    exit;
}

$workspace_id = $_SESSION['workspace_id'];
$lang = isset($_POST['lang']) ? $_POST['lang'] : 'bg';

// Get data
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$registration_number = isset($_POST['registration_number']) ? trim($_POST['registration_number']) : '';
$driving_license_category = isset($_POST['driving_license_category']) ? trim($_POST['driving_license_category']) : '';
$eco_group = isset($_POST['eco_group']) ? trim($_POST['eco_group']) : null;
$civil_insurance_expiry = isset($_POST['civil_insurance_expiry']) && !empty($_POST['civil_insurance_expiry']) ? $_POST['civil_insurance_expiry'] : null;
$vignette_expiry = isset($_POST['vignette_expiry']) && !empty($_POST['vignette_expiry']) ? $_POST['vignette_expiry'] : null;
$vehicle_inspection_expiry = isset($_POST['vehicle_inspection_expiry']) && !empty($_POST['vehicle_inspection_expiry']) ? $_POST['vehicle_inspection_expiry'] : null;
// Validate
if (empty($name) || empty($registration_number) || empty($driving_license_category)) {
    header("Location: /office-manager/setup-transport.php?error=required&lang=$lang");
    exit;
}

// Database
require_once __DIR__ . '/../../config/database.php';

try {
    $db = get_db_connection();
    
    // Check if registration already exists
    $stmt = $db->prepare("
        SELECT id FROM vehicles 
        WHERE workspace_id = ? AND registration_number = ? AND is_active = 1
    ");
    $stmt->execute(array($workspace_id, $registration_number));
    if ($stmt->fetch()) {
        header("Location: /office-manager/setup-transport.php?error=exists&lang=$lang");
        exit;
    }
    

$stmt = $db->prepare("
    INSERT INTO vehicles 
    (workspace_id, name, registration_number, driving_license_category, eco_group, civil_insurance_expiry, vignette_expiry, vehicle_inspection_expiry, is_active, created_at) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())
    ");
    $stmt->execute(array(
    $workspace_id,
    $name,
    $registration_number,
    $driving_license_category,
    $eco_group,
    $civil_insurance_expiry,
    $vignette_expiry,
    $vehicle_inspection_expiry
));
    
    header("Location: /office-manager/setup-transport.php?success=1&lang=$lang");
    exit;
    
} catch (Exception $e) {
    error_log("Add vehicle error: " . $e->getMessage());
    header("Location: /office-manager/setup-transport.php?error=system&lang=$lang");
    exit;
}
