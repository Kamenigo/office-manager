<?php
/**
 * Office Manager - Database Configuration
 */

// Database credentials
define('DB_HOST', 'localhost');
define('DB_NAME', 'refurnis_TaskPilot');
define('DB_USER', 'refurnis_task');
define('DB_PASS', 'Kamenigo_77');  // ЗАМЕНИ С ТВОЯТА ПАРОЛА!

/**
 * Get database connection
 * @return PDO
 */
function get_db_connection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        );
        
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
        
    } catch (PDOException $e) {
        error_log("Database connection error: " . $e->getMessage());
        die("Database connection failed. Please check your configuration.");
    }
}
