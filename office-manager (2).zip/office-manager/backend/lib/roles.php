<?php
/**
 * Roles & Permissions Library
 * Проверява роли и права на потребители
 */

/**
 * Взима ролята на текущия потребител във workspace
 */
function get_user_role() {
    if (empty($_SESSION['role'])) {
        return null;
    }
    return $_SESSION['role'];
}

/**
 * Проверява дали потребителят има определена роля
 */
function has_role($required_role) {
    $user_role = get_user_role();
    if (!$user_role) {
        return false;
    }
    
    // Ако е array от роли
    if (is_array($required_role)) {
        return in_array($user_role, $required_role);
    }
    
    // Ако е една роля
    return $user_role === $required_role;
}

/**
 * Проверява дали потребителят е Admin
 */
function is_admin() {
    return has_role('admin');
}

/**
 * Проверява дали потребителят е PM (Project Manager)
 */
function is_pm() {
    return has_role('pm');
}

/**
 * Проверява дали потребителят е Accountant (Счетоводител)
 */
function is_accountant() {
    return has_role('accountant');
}

/**
 * Проверява дали потребителят е Worker
 */
function is_worker() {
    return has_role('worker');
}

/**
 * Проверява дали потребителят има Admin ИЛИ PM роля
 */
function is_admin_or_pm() {
    return has_role(['admin', 'pm']);
}

/**
 * Изисква определена роля - ако няма, redirect към 403
 */
function require_role($required_role) {
    if (!has_role($required_role)) {
        http_response_code(403);
        die('Access denied. Insufficient permissions.');
    }
}

/**
 * Изисква Admin роля
 */
function require_admin() {
    require_role('admin');
}

/**
 * Изисква Admin ИЛИ PM
 */
function require_admin_or_pm() {
    if (!is_admin_or_pm()) {
        http_response_code(403);
        die('Access denied. Admin or PM role required.');
    }
}

/**
 * Проверява дали потребителят може да вижда записа на друг потребител
 * 
 * Правила:
 * - Admin: вижда всички
 * - PM: вижда само своя екип (workspace)
 * - Accountant: вижда всички (read-only)
 * - Worker: вижда само свои
 */
function can_view_user($target_user_id) {
    $current_user_id = $_SESSION['user_id'] ?? null;
    $role = get_user_role();
    
    if (!$current_user_id || !$role) {
        return false;
    }
    
    // Собствен профил - всеки може да вижда
    if ($target_user_id == $current_user_id) {
        return true;
    }
    
    // Admin вижда всички
    if ($role === 'admin') {
        return true;
    }
    
    // Accountant вижда всички
    if ($role === 'accountant') {
        return true;
    }
    
    // PM вижда само своя workspace
    if ($role === 'pm') {
        return is_same_workspace($target_user_id);
    }
    
    // Worker вижда само себе си
    return false;
}

/**
 * Проверява дали друг потребител е в същия workspace
 */
function is_same_workspace($target_user_id) {
    $workspace_id = $_SESSION['workspace_id'] ?? null;
    if (!$workspace_id) {
        return false;
    }
    
    require_once __DIR__ . '/../config/database.php';
    try {
        $db = get_db_connection();
        $stmt = $db->prepare("
            SELECT 1 FROM workspace_members 
            WHERE workspace_id = ? AND user_id = ? AND is_active = 1
        ");
        $stmt->execute(array($workspace_id, $target_user_id));
        return (bool)$stmt->fetch();
    } catch (Exception $e) {
        error_log("Workspace check error: " . $e->getMessage());
        return false;
    }
}

/**
 * Проверява дали потребителят може да редактира запис на друг потребител
 * 
 * Правила:
 * - Admin: редактира всички
 * - PM: редактира своя екип
 * - Accountant: НЕ редактира
 * - Worker: редактира само свои
 */
function can_edit_user($target_user_id) {
    $current_user_id = $_SESSION['user_id'] ?? null;
    $role = get_user_role();
    
    if (!$current_user_id || !$role) {
        return false;
    }
    
    // Собствен профил - всеки може да редактира
    if ($target_user_id == $current_user_id) {
        return true;
    }
    
    // Admin редактира всички
    if ($role === 'admin') {
        return true;
    }
    
    // PM редактира своя workspace
    if ($role === 'pm') {
        return is_same_workspace($target_user_id);
    }
    
    // Accountant НЕ редактира
    // Worker НЕ редактира други
    return false;
}

/**
 * Проверява дали потребителят може да деактивира друг потребител
 * 
 * Правила:
 * - Admin: може да деактивира всички директно
 * - PM: може да деактивира Worker (изисква одобрение от Admin)
 * - PM: НЕ може да деактивира Admin или друг PM
 * - Други: НЕ могат
 */
function can_deactivate_user($target_user_id) {
    $role = get_user_role();
    
    if (!$role) {
        return false;
    }
    
    // Admin може да деактивира всички
    if ($role === 'admin') {
        return true;
    }
    
    // PM може да деактивира само Workers от своя workspace
    if ($role === 'pm') {
        // Провери дали target е Worker
        $target_role = get_user_role_by_id($target_user_id);
        if ($target_role !== 'worker') {
            return false; // PM не може да деактивира Admin/PM/Accountant
        }
        
        // Провери дали е от същия workspace
        return is_same_workspace($target_user_id);
    }
    
    // Други роли не могат
    return false;
}

/**
 * Взима ролята на потребител по ID
 */
function get_user_role_by_id($user_id) {
    require_once __DIR__ . '/../config/database.php';
    try {
        $db = get_db_connection();
        $stmt = $db->prepare("
            SELECT role FROM workspace_members 
            WHERE user_id = ? AND is_active = 1 
            LIMIT 1
        ");
        $stmt->execute(array($user_id));
        $result = $stmt->fetch();
        return $result ? $result['role'] : null;
    } catch (Exception $e) {
        error_log("Get user role error: " . $e->getMessage());
        return null;
    }
}

/**
 * Записва действие в audit log
 */
function log_action($action, $target_user_id = null, $old_value = null, $new_value = null) {
    require_once __DIR__ . '/../config/database.php';
    
    $workspace_id = $_SESSION['workspace_id'] ?? null;
    $user_id = $_SESSION['user_id'] ?? null;
    $ip = $_SERVER['REMOTE_ADDR'] ?? null;
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? null;
    
    try {
        $db = get_db_connection();
        $stmt = $db->prepare("
            INSERT INTO audit_log 
            (workspace_id, user_id, action, target_user_id, old_value, new_value, ip_address, user_agent, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute(array(
            $workspace_id,
            $user_id,
            $action,
            $target_user_id,
            $old_value ? json_encode($old_value) : null,
            $new_value ? json_encode($new_value) : null,
            $ip,
            $user_agent
        ));
    } catch (Exception $e) {
        error_log("Audit log error: " . $e->getMessage());
    }
}

/**
 * Получава статуса на потребител
 */
function get_user_status($user_id) {
    require_once __DIR__ . '/../config/database.php';
    try {
        $db = get_db_connection();
        $stmt = $db->prepare("SELECT status FROM users WHERE id = ?");
        $stmt->execute(array($user_id));
        $result = $stmt->fetch();
        return $result ? $result['status'] : null;
    } catch (Exception $e) {
        error_log("Get user status error: " . $e->getMessage());
        return null;
    }
}
