<?php
// backend/lib/auth_guard.php
// Session management and authentication guards

function om_start_session() {
  if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    session_start();
  }
}

function om_require_login() {
  om_start_session();

  if (empty($_SESSION['user_id'])) {
    header('Location: /office-manager/login.php');
    exit;
  }

  // SECURITY: Email verification is MANDATORY
  if (empty($_SESSION['is_email_verified']) || $_SESSION['is_email_verified'] != 1) {
    header('Location: /office-manager/verify-required.php');
    exit;
  }
  
  // SECURITY: Workspace membership is MANDATORY (except for onboarding pages)
  $current_page = basename($_SERVER['PHP_SELF']);
  $onboarding_pages = array('onboarding.php', 'select-modules.php');
  
  if (!in_array($current_page, $onboarding_pages)) {
    if (empty($_SESSION['workspace_id'])) {
      header('Location: /office-manager/onboarding.php');
      exit;
    }
  }
}

/**
 * @param array $allowed_roles e.g. ['admin','pm']
 */
function om_require_role($allowed_roles) {
  om_require_login();

  $role = isset($_SESSION['role']) ? $_SESSION['role'] : null;
  if (!$role || !in_array($role, $allowed_roles, true)) {
    http_response_code(403);
    echo "403 Forbidden";
    exit;
  }
}
