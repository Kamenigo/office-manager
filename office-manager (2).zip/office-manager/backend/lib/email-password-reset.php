<?php
/**
 * Send password reset email
 * @param string $to Email address
 * @param string $name User's full name
 * @param string $token Reset token
 * @param string $lang Language (bg, en, ru)
 * @return bool Success or failure
 */
function send_password_reset_email($to, $name, $token, $lang = 'bg') {
    
    // Reset link
    $reset_link = "https://re-furnishbg.com/office-manager/reset-password.php?token=" . urlencode($token) . "&lang=" . urlencode($lang);
    
    // Translations
    $translations = array(
        'bg' => array(
            'subject' => 'Възстановяване на парола - Office Manager',
            'greeting' => 'Здравей',
            'message' => 'Получихме заявка за възстановяване на паролата за твоя акаунт.',
            'instruction' => 'Кликни на бутона по-долу за да зададеш нова парола:',
            'button' => 'Възстанови парола',
            'expire' => 'Този линк е валиден 1 час.',
            'ignore' => 'Ако не си поискал възстановяване на парола, игнорирай този имейл.',
            'security' => 'Паролата ти остава непроменена докато не кликнеш на линка.',
        ),
        'en' => array(
            'subject' => 'Password Reset - Office Manager',
            'greeting' => 'Hello',
            'message' => 'We received a request to reset the password for your account.',
            'instruction' => 'Click the button below to set a new password:',
            'button' => 'Reset Password',
            'expire' => 'This link is valid for 1 hour.',
            'ignore' => 'If you did not request a password reset, ignore this email.',
            'security' => 'Your password remains unchanged until you click the link.',
        ),
        'ru' => array(
            'subject' => 'Восстановление пароля - Office Manager',
            'greeting' => 'Здравствуйте',
            'message' => 'Мы получили запрос на восстановление пароля для вашего аккаунта.',
            'instruction' => 'Нажмите на кнопку ниже, чтобы установить новый пароль:',
            'button' => 'Восстановить пароль',
            'expire' => 'Эта ссылка действительна 1 час.',
            'ignore' => 'Если вы не запрашивали восстановление пароля, проигнорируйте это письмо.',
            'security' => 'Ваш пароль остается неизменным, пока вы не нажмете на ссылку.',
        ),
    );
    
    $t = isset($translations[$lang]) ? $translations[$lang] : $translations['bg'];
    
    // Email subject with MIME encoding for Cyrillic
    $subject = "=?UTF-8?B?" . base64_encode($t['subject']) . "?=";
    
    // HTML email body
    $message = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
    </head>
    <body style='margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #1a1a1a;'>
        <table width='100%' cellpadding='0' cellspacing='0' style='background-color: #1a1a1a; padding: 40px 20px;'>
            <tr>
                <td align='center'>
                    <table width='600' cellpadding='0' cellspacing='0' style='background-color: #2a2a2a; border-radius: 12px; overflow: hidden;'>
                        
                        <!-- Header -->
                        <tr>
                            <td style='padding: 40px; text-align: center; background: linear-gradient(135deg, #D4AF37, #C5A028);'>
                                <div style='width: 64px; height: 64px; background: #1a1a1a; border-radius: 12px; margin: 0 auto 16px; display: flex; align-items: center; justify-content: center; font-size: 28px; font-weight: bold; color: #D4AF37; line-height: 64px;'>OM</div>
                                <h1 style='margin: 0; color: #1a1a1a; font-size: 24px; font-weight: 600;'>Office Manager</h1>
                            </td>
                        </tr>
                        
                        <!-- Body -->
                        <tr>
                            <td style='padding: 40px; color: #e5e5e5;'>
                                <p style='margin: 0 0 20px; font-size: 16px;'>{$t['greeting']} <strong>" . htmlspecialchars($name) . "</strong>,</p>
                                <p style='margin: 0 0 20px; font-size: 16px; line-height: 1.6;'>{$t['message']}</p>
                                <p style='margin: 0 0 30px; font-size: 16px; line-height: 1.6;'>{$t['instruction']}</p>
                                
                                <!-- Button -->
                                <table width='100%' cellpadding='0' cellspacing='0'>
                                    <tr>
                                        <td align='center' style='padding: 20px 0;'>
                                            <a href='{$reset_link}' style='display: inline-block; padding: 16px 40px; background: linear-gradient(135deg, #D4AF37, #C5A028); color: #1a1a1a; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px;'>{$t['button']}</a>
                                        </td>
                                    </tr>
                                </table>
                                
                                <p style='margin: 30px 0 0; font-size: 14px; color: #999; line-height: 1.6;'><strong>⏱ {$t['expire']}</strong></p>
                                <p style='margin: 10px 0 0; font-size: 14px; color: #999; line-height: 1.6;'>{$t['security']}</p>
                                <p style='margin: 10px 0 0; font-size: 14px; color: #999; line-height: 1.6;'>{$t['ignore']}</p>
                            </td>
                        </tr>
                        
                        <!-- Footer -->
                        <tr>
                            <td style='padding: 30px 40px; text-align: center; border-top: 1px solid #3a3a3a;'>
                                <p style='margin: 0; font-size: 12px; color: #666;'>© " . date('Y') . " Office Manager. All rights reserved.</p>
                            </td>
                        </tr>
                        
                    </table>
                </td>
            </tr>
        </table>
    </body>
    </html>
    ";
    
    // Email headers
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
    $headers .= "From: Office Manager <noreply@re-furnishbg.com>" . "\r\n";
    
    // Send email
    return mail($to, $subject, $message, $headers);
}
