<?php
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Language
$lang = isset($_GET['lang']) ? $_GET['lang'] : (isset($_SESSION['lang']) ? $_SESSION['lang'] : 'bg');
if (in_array($lang, array('bg', 'en', 'ru'))) {
  $_SESSION['lang'] = $lang;
} else {
  $lang = 'bg';
}

$t = array(
  'bg' => array(
    'title' => 'Регистрация',
    'subtitle' => 'Създай нов акаунт',
    'name' => 'Име и фамилия',
    'email' => 'Имейл адрес',
    'phone' => 'Телефон (напр. 0888123456)',
    'password' => 'Парола',
    'confirm' => 'Потвърди паролата',
    'btn' => 'Регистрация',
    'have_account' => 'Вече имаш акаунт?',
    'login' => 'Влез тук',
    'help' => 'Минимум 6 символа, букви + цифри',
    'error_empty' => 'Моля попълни всички задължителни полета.',
    'error_invalid_email' => 'Невалиден имейл адрес.',
    'error_short' => 'Паролата трябва да е минимум 6 символа.',
    'error_weak' => 'Паролата трябва да съдържа букви и цифри.',
    'error_mismatch' => 'Паролите не съвпадат.',
    'error_exists' => 'Този имейл вече е регистриран.',
    'error_failed' => 'Грешка при регистрацията.',
    'error_system' => 'Системна грешка.',
  ),
  'en' => array(
    'title' => 'Register',
    'subtitle' => 'Create new account',
    'name' => 'Full name',
    'email' => 'Email address',
    'phone' => 'Phone (e.g. 0888123456)',
    'password' => 'Password',
    'confirm' => 'Confirm password',
    'btn' => 'Register',
    'have_account' => 'Already have account?',
    'login' => 'Login here',
    'help' => 'Minimum 6 characters, letters + numbers',
    'error_empty' => 'Please fill all required fields.',
    'error_invalid_email' => 'Invalid email address.',
    'error_short' => 'Password must be at least 6 characters.',
    'error_weak' => 'Password must contain letters and numbers.',
    'error_mismatch' => 'Passwords do not match.',
    'error_exists' => 'This email is already registered.',
    'error_failed' => 'Registration error.',
    'error_system' => 'System error.',
  ),
  'ru' => array(
    'title' => 'Регистрация',
    'subtitle' => 'Создать новый аккаунт',
    'name' => 'Имя и фамилия',
    'email' => 'Email адрес',
    'phone' => 'Телефон (напр. 0888123456)',
    'password' => 'Пароль',
    'confirm' => 'Подтвердите пароль',
    'btn' => 'Регистрация',
    'have_account' => 'Уже есть аккаунт?',
    'login' => 'Войти',
    'help' => 'Минимум 6 символов, буквы + цифры',
    'error_empty' => 'Пожалуйста, заполните все обязательные поля.',
    'error_invalid_email' => 'Неверный email адрес.',
    'error_short' => 'Пароль должен быть не менее 6 символов.',
    'error_weak' => 'Пароль должен содержать буквы и цифры.',
    'error_mismatch' => 'Пароли не совпадают.',
    'error_exists' => 'Этот email уже зарегистрирован.',
    'error_failed' => 'Ошибка регистрации.',
    'error_system' => 'Системная ошибка.',
  ),
);

$tr = $t[$lang];
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tr['title']; ?> – Office Manager</title>
    <style>
        body{margin:0;padding:0;background:#1a1a1a;color:#e5e5e5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center}
        .register-container{width:100%;max-width:450px;padding:20px}
        .register-card{background:#2a2a2a;border:1px solid #3a3a3a;border-radius:12px;padding:40px 30px;box-shadow:0 4px 20px rgba(0,0,0,.3)}
        .register-logo{text-align:center;margin-bottom:30px}
        .register-logo-icon{width:64px;height:64px;background:linear-gradient(135deg,#D4AF37,#C5A028);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:28px;font-weight:bold;color:#1a1a1a;box-shadow:0 0 0 3px rgba(212,175,55,.3)}
        .register-logo-title{font-size:28px;font-weight:300;color:#e5e5e5;margin-top:16px;margin-bottom:0}
        .register-subtitle{text-align:center;font-size:14px;color:#999;margin-bottom:30px;margin-top:8px}
        .register-input{width:100%;background:#1a1a1a;border:1px solid #3a3a3a;padding:14px 16px;color:#e5e5e5;border-radius:8px;margin-bottom:16px;font-size:15px;font-family:inherit;box-sizing:border-box}
        .register-input:focus{outline:0;border-color:#D4AF37;box-shadow:0 0 0 3px rgba(212,175,55,.1)}
        .register-input::placeholder{color:#666}
        .register-btn{width:100%;background:linear-gradient(135deg,#D4AF37,#C5A028);color:#1a1a1a;padding:14px;border-radius:8px;border:none;font-size:16px;cursor:pointer;transition:.2s;font-family:inherit;font-weight:600}
        .register-btn:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(212,175,55,.3)}
        .register-footer{text-align:center;margin-top:24px;font-size:14px;color:#666}
        .register-footer a{color:#D4AF37;text-decoration:none;font-weight:500}
        .register-footer a:hover{text-decoration:underline}
        .error-message{background:rgba(248,113,113,.1);border:1px solid #f87171;color:#f87171;padding:12px;border-radius:8px;margin-bottom:20px;font-size:14px;text-align:center}
        .help-text{font-size:12px;color:#666;margin-top:-12px;margin-bottom:12px;padding-left:4px}
        .lang-switcher{position:absolute;top:24px;right:24px;display:flex;gap:8px}
        .lang-btn{width:40px;height:28px;border-radius:6px;border:2px solid transparent;cursor:pointer;transition:.2s;text-decoration:none;overflow:hidden;position:relative}
        .lang-btn:hover{transform:scale(1.05)}
        .lang-btn.active{border-color:#D4AF37;box-shadow:0 0 0 2px rgba(212,175,55,.2)}
        .flag-bg{background:linear-gradient(to bottom,#FFF 0%,#FFF 33.33%,#00966E 33.33%,#00966E 66.66%,#D62612 66.66%,#D62612 100%)}
        .flag-en{background:#012169;position:relative}
        .flag-en::before{content:'';position:absolute;top:0;left:0;right:0;bottom:0;background:linear-gradient(to bottom,transparent 40%,#FFF 40%,#FFF 60%,transparent 60%),linear-gradient(to right,transparent 40%,#FFF 40%,#FFF 60%,transparent 60%)}
        .flag-en::after{content:'';position:absolute;top:0;left:0;right:0;bottom:0;background:linear-gradient(to bottom,transparent 45%,#C8102E 45%,#C8102E 55%,transparent 55%),linear-gradient(to right,transparent 45%,#C8102E 45%,#C8102E 55%,transparent 55%)}
        .flag-ru{background:linear-gradient(to bottom,#FFF 0%,#FFF 33.33%,#0039A6 33.33%,#0039A6 66.66%,#D52B1E 66.66%,#D52B1E 100%)}
        @media (max-width:768px){
            .register-container{max-width:340px}
            .register-card{padding:30px 20px}
            .lang-switcher{top:16px;right:16px}
        }
    </style>
</head>
<body>
<div class="lang-switcher">
    <a href="?lang=bg" class="lang-btn flag-bg <?php echo ($lang === 'bg') ? 'active' : ''; ?>" title="Български"></a>
    <a href="?lang=en" class="lang-btn flag-en <?php echo ($lang === 'en') ? 'active' : ''; ?>" title="English"></a>
    <a href="?lang=ru" class="lang-btn flag-ru <?php echo ($lang === 'ru') ? 'active' : ''; ?>" title="Русский"></a>
</div>

<div class="register-container">
    <div class="register-card">
        <div class="register-logo">
            <div class="register-logo-icon">OM</div>
            <h1 class="register-logo-title">Office Manager</h1>
        </div>
        <p class="register-subtitle"><?php echo $tr['subtitle']; ?></p>
        
        <?php
        if(isset($_GET['success'])){
            echo '<div style="background:rgba(34,197,94,.1);border:1px solid #22c55e;color:#22c55e;padding:12px;border-radius:8px;margin-bottom:20px;font-size:14px;text-align:center">✓ ' . ($lang === 'bg' ? 'Регистрацията е успешна! Можеш да влезеш.' : ($lang === 'ru' ? 'Регистрация успешна! Можете войти.' : 'Registration successful! You can login.')) . '</div>';
        }
        
        if(isset($_GET['error'])){
            $error_key = 'error_' . htmlspecialchars($_GET['error']);
            echo '<div class="error-message">' . (isset($tr[$error_key]) ? $tr[$error_key] : $tr['error_system']) . '</div>';
        }
        ?>
        
        <form method="POST" action="backend/api/auth/register_process.php">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token'];?>">
            <input type="hidden" name="lang" value="<?php echo $lang;?>">
            
            <input type="text" name="name" class="register-input" placeholder="<?php echo $tr['name']; ?> *" required>
            
            <input type="email" name="email" class="register-input" placeholder="<?php echo $tr['email']; ?> *" required>
            
        <input type="tel" name="phone" class="register-input" placeholder="<?php echo $tr['phone']; ?> *" pattern="[0-9+\s\-()]+" title="Само цифри, +, тире и скоби" required>
            
            <input type="password" name="password" class="register-input" placeholder="<?php echo $tr['password']; ?> *" required minlength="6">
            <div class="help-text"><?php echo $tr['help']; ?></div>
            
            <input type="password" name="confirm_password" class="register-input" placeholder="<?php echo $tr['confirm']; ?> *" required minlength="6">
            
            <button type="submit" class="register-btn"><?php echo $tr['btn']; ?></button>
        </form>
        
        <div class="register-footer">
            <?php echo $tr['have_account']; ?> <a href="login.php?lang=<?php echo $lang; ?>"><?php echo $tr['login']; ?></a>
        </div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const phoneInput = document.querySelector('input[name="phone"]');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            // Allow only digits, +, -, space, parentheses
            this.value = this.value.replace(/[^0-9+\s\-()]/g, '');
        });
    }
});
</script>
</body>
</html>
