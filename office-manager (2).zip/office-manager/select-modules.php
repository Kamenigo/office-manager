<?php
require_once __DIR__ . '/backend/lib/auth_guard.php';
om_start_session();

// Must be logged in
if (empty($_SESSION['user_id'])) {
    header('Location: /office-manager/login.php');
    exit;
}

// If already has workspace, redirect to dashboard
require_once __DIR__ . '/backend/config/database.php';
try {
    $db = get_db_connection();
    $stmt = $db->prepare("
        SELECT workspace_id 
        FROM workspace_members 
        WHERE user_id = ? AND is_active = 1 
        LIMIT 1
    ");
    $stmt->execute(array($_SESSION['user_id']));
    if ($stmt->fetch()) {
        header('Location: /office-manager/dashboard.php');
        exit;
    }
} catch (Exception $e) {
    error_log("Module selection check error: " . $e->getMessage());
}

// Get language and workspace type from session
$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'bg';
$workspace_type = isset($_GET['type']) ? $_GET['type'] : 'solo';

$t = array(
  'bg' => array(
    'title' => 'Изберете модули',
    'subtitle' => 'Изберете функционалностите, които ще използвате',
    'select_all' => 'Избери всички',
    'deselect_all' => 'Премахни всички',
    'tasks' => 'Задачи',
    'tasks_desc' => 'Управление на задачи и дейности',
    'orders' => 'Поръчки',
    'orders_desc' => 'Управление на поръчки от клиенти',
    'transport' => 'Транспорт',
    'transport_desc' => 'Логистика и управление на транспорт',
    'calculator' => 'Калкулатор',
    'calculator_desc' => 'Калкулатор за ремонти и услуги',
    'clients' => 'Клиенти',
    'clients_desc' => 'База данни с клиенти',
    'employees' => 'Служители',
    'employees_desc' => 'Управление на екип и служители',
    'invoices' => 'Фактури',
    'invoices_desc' => 'Създаване и управление на фактури',
    'reports' => 'Отчети',
    'reports_desc' => 'Аналитични отчети и статистики',
    'purchases' => 'Покупки',
    'purchases_desc' => 'Управление на доставки и покупки',
    'btn_continue' => 'Продължи',
    'btn_back' => 'Назад',
    'selected' => 'избрани',
  ),
  'en' => array(
    'title' => 'Select Modules',
    'subtitle' => 'Choose the features you will use',
    'select_all' => 'Select All',
    'deselect_all' => 'Deselect All',
    'tasks' => 'Tasks',
    'tasks_desc' => 'Task and activity management',
    'orders' => 'Orders',
    'orders_desc' => 'Customer order management',
    'transport' => 'Transport',
    'transport_desc' => 'Logistics and transport management',
    'calculator' => 'Calculator',
    'calculator_desc' => 'Calculator for repairs and services',
    'clients' => 'Clients',
    'clients_desc' => 'Client database',
    'employees' => 'Employees',
    'employees_desc' => 'Team and staff management',
    'invoices' => 'Invoices',
    'invoices_desc' => 'Create and manage invoices',
    'reports' => 'Reports',
    'reports_desc' => 'Analytics and statistics',
    'purchases' => 'Purchases',
    'purchases_desc' => 'Supply and purchase management',
    'btn_continue' => 'Continue',
    'btn_back' => 'Back',
    'selected' => 'selected',
  ),
  'ru' => array(
    'title' => 'Выберите модули',
    'subtitle' => 'Выберите функции, которые будете использовать',
    'select_all' => 'Выбрать все',
    'deselect_all' => 'Снять все',
    'tasks' => 'Задачи',
    'tasks_desc' => 'Управление задачами и деятельностью',
    'orders' => 'Заказы',
    'orders_desc' => 'Управление заказами клиентов',
    'transport' => 'Транспорт',
    'transport_desc' => 'Логистика и управление транспортом',
    'calculator' => 'Калькулятор',
    'calculator_desc' => 'Калькулятор для ремонта и услуг',
    'clients' => 'Клиенты',
    'clients_desc' => 'База данных клиентов',
    'employees' => 'Сотрудники',
    'employees_desc' => 'Управление командой и персоналом',
    'invoices' => 'Счета',
    'invoices_desc' => 'Создание и управление счетами',
    'reports' => 'Отчеты',
    'reports_desc' => 'Аналитика и статистика',
    'purchases' => 'Покупки',
    'purchases_desc' => 'Управление поставками и покупками',
    'btn_continue' => 'Продолжить',
    'btn_back' => 'Назад',
    'selected' => 'выбрано',
  ),
);

$tr = $t[$lang];

// Available modules
$modules = array(
  array('id' => 'tasks', 'icon' => '📋', 'name' => $tr['tasks'], 'desc' => $tr['tasks_desc']),
  array('id' => 'orders', 'icon' => '📦', 'name' => $tr['orders'], 'desc' => $tr['orders_desc']),
  array('id' => 'clients', 'icon' => '👥', 'name' => $tr['clients'], 'desc' => $tr['clients_desc']),
  array('id' => 'employees', 'icon' => '👔', 'name' => $tr['employees'], 'desc' => $tr['employees_desc']),
  array('id' => 'calculator', 'icon' => '🧮', 'name' => $tr['calculator'], 'desc' => $tr['calculator_desc']),
  array('id' => 'transport', 'icon' => '🚚', 'name' => $tr['transport'], 'desc' => $tr['transport_desc']),
  array('id' => 'invoices', 'icon' => '📄', 'name' => $tr['invoices'], 'desc' => $tr['invoices_desc']),
  array('id' => 'purchases', 'icon' => '🛒', 'name' => $tr['purchases'], 'desc' => $tr['purchases_desc']),
  array('id' => 'reports', 'icon' => '📊', 'name' => $tr['reports'], 'desc' => $tr['reports_desc'])
);
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tr['title']; ?> - Office Manager</title>
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{background:#1a1a1a;color:#e5e5e5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
        .container{width:100%;max-width:900px}
        .header{text-align:center;margin-bottom:48px}
        .logo{width:64px;height:64px;background:linear-gradient(135deg,#D4AF37,#C5A028);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:28px;font-weight:bold;color:#1a1a1a;box-shadow:0 0 0 3px rgba(212,175,55,.3);margin-bottom:24px}
        h1{font-size:32px;font-weight:300;margin-bottom:12px}
        .subtitle{color:#999;font-size:16px}
        .toolbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;padding:16px 20px;background:#2a2a2a;border:1px solid #3a3a3a;border-radius:8px}
        .toolbar-left{display:flex;gap:12px}
        .toolbar-btn{background:#1a1a1a;border:1px solid #3a3a3a;color:#e5e5e5;padding:8px 16px;border-radius:6px;font-size:14px;cursor:pointer;transition:.2s}
        .toolbar-btn:hover{border-color:#D4AF37;background:#2a2a2a}
        .counter{color:#D4AF37;font-weight:600;font-size:14px}
        .modules-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;margin-bottom:32px}
        .module-card{background:#2a2a2a;border:2px solid #3a3a3a;border-radius:12px;padding:24px;cursor:pointer;transition:.2s;position:relative}
        .module-card:hover{border-color:#D4AF37;transform:translateY(-2px)}
        .module-card.selected{border-color:#D4AF37;background:#2d2a23}
        .module-card.selected::after{content:'✓';position:absolute;top:12px;right:12px;width:24px;height:24px;background:#D4AF37;color:#1a1a1a;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:bold}
        .module-icon{font-size:32px;margin-bottom:12px}
        .module-name{font-size:18px;font-weight:600;margin-bottom:8px;color:#e5e5e5}
        .module-desc{font-size:14px;color:#999;line-height:1.5}
        .actions{display:flex;gap:16px;justify-content:center}
        .btn{padding:14px 32px;border-radius:8px;font-size:16px;font-weight:600;cursor:pointer;transition:.2s;text-decoration:none;display:inline-block;border:none}
        .btn-primary{background:linear-gradient(135deg,#D4AF37,#C5A028);color:#1a1a1a}
        .btn-primary:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(212,175,55,.3)}
        .btn-primary:disabled{opacity:.5;cursor:not-allowed;transform:none}
        .btn-secondary{background:#2a2a2a;border:1px solid #3a3a3a;color:#e5e5e5}
        .btn-secondary:hover{border-color:#D4AF37}
        @media (max-width:768px){
            .modules-grid{grid-template-columns:1fr}
            .toolbar{flex-direction:column;gap:12px}
            .toolbar-left{width:100%;justify-content:space-between}
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="logo">OM</div>
        <h1><?php echo $tr['title']; ?></h1>
        <p class="subtitle"><?php echo $tr['subtitle']; ?></p>
    </div>

    <div class="toolbar">
        <div class="toolbar-left">
            <button class="toolbar-btn" onclick="selectAll()"><?php echo $tr['select_all']; ?></button>
            <button class="toolbar-btn" onclick="deselectAll()"><?php echo $tr['deselect_all']; ?></button>
        </div>
        <div class="counter">
            <span id="selectedCount">0</span> <?php echo $tr['selected']; ?>
        </div>
    </div>

    <form method="POST" action="backend/api/workspace/create-workspace.php" id="moduleForm">
        <input type="hidden" name="workspace_type" value="<?php echo htmlspecialchars($workspace_type); ?>">
        <input type="hidden" name="lang" value="<?php echo $lang; ?>">
        
        <div class="modules-grid">
            <?php foreach ($modules as $module): ?>
            <div class="module-card" onclick="toggleModule('<?php echo $module['id']; ?>')">
                <div class="module-icon"><?php echo $module['icon']; ?></div>
                <div class="module-name"><?php echo $module['name']; ?></div>
                <div class="module-desc"><?php echo $module['desc']; ?></div>
                <input type="checkbox" name="modules[]" value="<?php echo $module['id']; ?>" style="display:none">
            </div>
            <?php endforeach; ?>
        </div>

        <div class="actions">
            <a href="onboarding.php?lang=<?php echo $lang; ?>" class="btn btn-secondary"><?php echo $tr['btn_back']; ?></a>
            <button type="submit" class="btn btn-primary" id="continueBtn"><?php echo $tr['btn_continue']; ?></button>
        </div>
    </form>
</div>

<script>
function toggleModule(moduleId) {
    const card = event.currentTarget;
    const checkbox = card.querySelector('input[type="checkbox"]');
    checkbox.checked = !checkbox.checked;
    card.classList.toggle('selected', checkbox.checked);
    updateCounter();
}

function selectAll() {
    document.querySelectorAll('.module-card').forEach(card => {
        card.classList.add('selected');
        card.querySelector('input[type="checkbox"]').checked = true;
    });
    updateCounter();
}

function deselectAll() {
    document.querySelectorAll('.module-card').forEach(card => {
        card.classList.remove('selected');
        card.querySelector('input[type="checkbox"]').checked = false;
    });
    updateCounter();
}

function updateCounter() {
    const count = document.querySelectorAll('input[type="checkbox"]:checked').length;
    document.getElementById('selectedCount').textContent = count;
    document.getElementById('continueBtn').disabled = count === 0;
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    updateCounter();
});
</script>

<?php include __DIR__ . '/components/user-menu.php'; ?>
</body>
</html>
