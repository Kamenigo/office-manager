<?php
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Get token and language from URL
$token = isset($_GET['token']) ? trim($_GET['token']) : '';
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'bg';

if (!in_array($lang, array('bg', 'en', 'ru'))) {
    $lang = 'bg';
}

$t = array(
  'bg' => array(
    'title' => 'Нова парола',
    'subtitle' => 'Задай нова парола за твоя акаунт',
    'password' => 'Нова парола',
    'confirm' => 'Потвърди паролата',
    'btn' => 'Запази парола',
    'help' => 'Минимум 6 символа, букви + цифри',
    'success_title' => '✓ Паролата е сменена!',
    'success_message' => 'Можеш да влезеш с новата парола.',
    'login_btn' => 'Влез в системата',
    'error_invalid' => 'Невалиден или изтекъл линк.',
    'error_expired' => 'Линкът е изтекъл. Поискай нов.',
    'error_short' => 'Паролата трябва да е минимум 6 символа.',
    'error_weak' => 'Паролата трябва да съдържа букви и цифри.',
    'error_mismatch' => 'Паролите не съвпадат.',
  ),
  'en' => array(
    'title' => 'New Password',
    'subtitle' => 'Set a new password for your account',
    'password' => 'New password',
    'confirm' => 'Confirm password',
    'btn' => 'Save Password',
    'help' => 'Minimum 6 characters, letters + numbers',
    'success_title' => '✓ Password Changed!',
    'success_message' => 'You can login with your new password.',
    'login_btn' => 'Login',
    'error_invalid' => 'Invalid or expired link.',
    'error_expired' => 'Link has expired. Request a new one.',
    'error_short' => 'Password must be at least 6 characters.',
    'error_weak' => 'Password must contain letters and numbers.',
    'error_mismatch' => 'Passwords do not match.',
  ),
  'ru' => array(
    'title' => 'Новый пароль',
    'subtitle' => 'Установите новый пароль для аккаунта',
    'password' => 'Новый пароль',
    'confirm' => 'Подтвердите пароль',
    'btn' => 'Сохранить пароль',
    'help' => 'Минимум 6 символов, буквы + цифры',
    'success_title' => '✓ Пароль изменен!',
    'success_message' => 'Вы можете войти с новым паролем.',
    'login_btn' => 'Войти',
    'error_invalid' => 'Неверная или истекшая ссылка.',
    'error_expired' => 'Ссылка истекла. Запросите новую.',
    'error_short' => 'Пароль должен быть не менее 6 символов.',
    'error_weak' => 'Пароль должен содержать буквы и цифры.',
    'error_mismatch' => 'Пароли не совпадают.',
  ),
);

$tr = $t[$lang];

// Validate token
$valid_token = false;
$error_message = '';

if (!empty($token)) {
    require_once __DIR__ . '/backend/config/database.php';
    
    try {
        $db = get_db_connection();
        
        // Check if token is valid
        $stmt = $db->prepare("
            SELECT id, password_reset_expires_at 
            FROM users 
            WHERE password_reset_token = ?
            LIMIT 1
        ");
        $stmt->execute(array($token));
        $user = $stmt->fetch();
        
        if (!$user) {
            $error_message = $tr['error_invalid'];
        } elseif (strtotime($user['password_reset_expires_at']) < time()) {
            $error_message = $tr['error_expired'];
        } else {
            $valid_token = true;
        }
        
    } catch (Exception $e) {
        error_log("Token validation error: " . $e->getMessage());
        $error_message = $tr['error_invalid'];
    }
} else {
    $error_message = $tr['error_invalid'];
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tr['title']; ?> – Office Manager</title>
    <style>
        body{margin:0;padding:0;background:#1a1a1a;color:#e5e5e5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center}
        .reset-container{width:100%;max-width:450px;padding:20px}
        .reset-card{background:#2a2a2a;border:1px solid #3a3a3a;border-radius:12px;padding:40px 30px;box-shadow:0 4px 20px rgba(0,0,0,.3)}
        .reset-logo{text-align:center;margin-bottom:30px}
        .reset-logo-icon{width:64px;height:64px;background:linear-gradient(135deg,#D4AF37,#C5A028);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:28px;font-weight:bold;color:#1a1a1a;box-shadow:0 0 0 3px rgba(212,175,55,.3)}
        .reset-logo-title{font-size:28px;font-weight:300;color:#e5e5e5;margin-top:16px;margin-bottom:0}
        .reset-subtitle{text-align:center;font-size:14px;color:#999;margin-bottom:30px;margin-top:8px}
        .reset-input{width:100%;background:#1a1a1a;border:1px solid #3a3a3a;padding:14px 16px;color:#e5e5e5;border-radius:8px;margin-bottom:16px;font-size:15px;font-family:inherit;box-sizing:border-box}
        .reset-input:focus{outline:0;border-color:#D4AF37;box-shadow:0 0 0 3px rgba(212,175,55,.1)}
        .reset-input::placeholder{color:#666}
        .reset-btn{width:100%;background:linear-gradient(135deg,#D4AF37,#C5A028);color:#1a1a1a;padding:14px;border-radius:8px;border:none;font-size:16px;cursor:pointer;transition:.2s;font-family:inherit;font-weight:600}
        .reset-btn:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(212,175,55,.3)}
        .error-message{background:rgba(248,113,113,.1);border:1px solid #f87171;color:#f87171;padding:20px;border-radius:8px;margin-bottom:20px;font-size:16px;text-align:center}
        .success-message{background:rgba(34,197,94,.1);border:1px solid #22c55e;color:#22c55e;padding:20px;border-radius:8px;margin-bottom:20px;font-size:16px;text-align:center}
        .help-text{font-size:12px;color:#666;margin-top:-12px;margin-bottom:12px;padding-left:4px}
        .success-icon{font-size:64px;margin-bottom:20px;text-align:center}
        @media (max-width:768px){
            .reset-container{max-width:340px}
            .reset-card{padding:30px 20px}
        }
    </style>
</head>
<body>
<div class="reset-container">
    <div class="reset-card">
        <div class="reset-logo">
            <div class="reset-logo-icon">OM</div>
            <h1 class="reset-logo-title">Office Manager</h1>
        </div>
        
        <?php if(isset($_GET['success'])): ?>
            <div class="success-icon">✓</div>
            <p class="reset-subtitle"><?php echo $tr['success_title']; ?></p>
            <div class="success-message"><?php echo $tr['success_message']; ?></div>
            <a href="login.php?lang=<?php echo $lang; ?>" class="reset-btn" style="display:block;text-align:center;text-decoration:none;">
                <?php echo $tr['login_btn']; ?>
            </a>
            
        <?php elseif(!$valid_token): ?>
            <p class="reset-subtitle">✗ <?php echo $tr['title']; ?></p>
            <div class="error-message"><?php echo $error_message; ?></div>
            <a href="forgot-password.php?lang=<?php echo $lang; ?>" class="reset-btn" style="display:block;text-align:center;text-decoration:none;background:#2a2a2a;border:1px solid #3a3a3a;color:#e5e5e5;">
                Поискай нов линк
            </a>
            
        <?php else: ?>
            <p class="reset-subtitle"><?php echo $tr['subtitle']; ?></p>
            
            <?php if(isset($_GET['error'])): ?>
                <div class="error-message">
                    <?php
                        $error = htmlspecialchars($_GET['error']);
                        if ($error === 'short') echo $tr['error_short'];
                        elseif ($error === 'weak') echo $tr['error_weak'];
                        elseif ($error === 'mismatch') echo $tr['error_mismatch'];
                        else echo $tr['error_invalid'];
                    ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="backend/api/auth/reset-password-process.php">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token'];?>">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token);?>">
                <input type="hidden" name="lang" value="<?php echo $lang;?>">
                
                <input type="password" name="password" class="reset-input" placeholder="<?php echo $tr['password']; ?>" required minlength="6">
                <div class="help-text"><?php echo $tr['help']; ?></div>
                
                <input type="password" name="confirm_password" class="reset-input" placeholder="<?php echo $tr['confirm']; ?>" required minlength="6">
                
                <button type="submit" class="reset-btn"><?php echo $tr['btn']; ?></button>
            </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
